<?php
/**
 * WP-CLI command for Agend Directory Sync.
 *
 * Exposes the same fetch -> transform -> send pipeline the admin "Send to
 * Agend" button uses, so the sync can run unattended from the server's cron:
 *
 *   wp agend-directory-sync run
 *
 * Add a crontab entry that cd's to the WordPress root and runs the command on
 * the cadence you want (see README.md for a copy-paste example). Running from
 * real cron means the sync does not depend on site traffic the way WP-Cron
 * does.
 *
 * This file is only loaded under WP-CLI; the command class is never defined in
 * a web request.
 *
 * @package Agend_Directory_Sync
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	return;
}

if ( ! class_exists( 'Agend_Directory_Sync_CLI_Command' ) ) :
	/**
	 * Run the Upbeat -> Agend directory sync from the command line.
	 */
	final class Agend_Directory_Sync_CLI_Command {

		/**
		 * Fetch members from the source, transform them, and push to the Agend
		 * directory.
		 *
		 * ## OPTIONS
		 *
		 * [--max=<number>]
		 * : Cap the number of source rows processed this run, applied after the
		 *   fetch and before transforming. Useful for a small verification run.
		 *   0 or omitted means process all rows.
		 *
		 * [--dry-run]
		 * : Fetch and transform only; do not POST anything to Agend. Reports the
		 *   counts that a real run would produce.
		 *
		 * [--secondary-filter=<fetchxml>]
		 * : Microsoft Dataverse source only. A FetchXML <filter> (or single
		 *   <condition>) fragment applied on top of the saved query for this
		 *   run, replacing the saved secondary filter, so a grouped upload can
		 *   be scripted one group at a time. The saved query is not changed.
		 *   Mutually exclusive with --secondary-filter-field and
		 *   --secondary-filter-values.
		 *
		 * [--secondary-filter-field=<name>]
		 * : Microsoft Dataverse source only. The guided alternative to
		 *   --secondary-filter: the logical name of the field to filter on,
		 *   paired with --secondary-filter-values. Mutually exclusive with
		 *   --secondary-filter.
		 *
		 * [--secondary-filter-values=<v1,v2>]
		 * : Comma separated raw values (a choice value, a GUID, or true/false)
		 *   to match --secondary-filter-field against. Required together
		 *   with --secondary-filter-field.
		 *
		 * ## EXAMPLES
		 *
		 *     wp agend-directory-sync run
		 *     wp agend-directory-sync run --max=50 --dry-run
		 *     wp agend-directory-sync run --secondary-filter='<condition attribute="pca_membergroup" operator="eq" value="Region North" />'
		 *     wp agend-directory-sync run --secondary-filter-field=pca_membergroup --secondary-filter-values=798380003,798380004
		 *
		 * @param array<int, string>    $args       Positional args (unused).
		 * @param array<string, string> $assoc_args Associative args.
		 *
		 * @return void
		 */
		public function run( $args, $assoc_args ): void {
			$max     = isset( $assoc_args['max'] ) ? max( 0, (int) $assoc_args['max'] ) : 0;
			$dry_run = isset( $assoc_args['dry-run'] );

			if ( $dry_run ) {
				WP_CLI::log( 'Dry run: fetching and transforming only, nothing will be sent.' );
			}

			if ( isset( $assoc_args['secondary-filter'] ) || isset( $assoc_args['secondary-filter-field'] ) || isset( $assoc_args['secondary-filter-values'] ) ) {
				$this->apply_secondary_filter_args( $assoc_args );
			}

			try {
				$summary = Agend_Directory_Sync_Runner::run( $max, $dry_run, 'cli' );
			} catch ( Throwable $e ) {
				WP_CLI::error( 'Sync failed: ' . $e->getMessage() );
				return;
			}

			if ( ! empty( $summary['page_window_truncated'] ) ) {
				WP_CLI::warning(
					sprintf(
						'Partial fetch: stopped after %d page(s) because of the configured page window, with more records available at the source.',
						(int) ( $summary['pages_fetched'] ?? 0 )
					)
				);
			}

			WP_CLI::log( sprintf( 'Fetched: %d', (int) $summary['fetched'] ) );
			WP_CLI::log( sprintf( 'Transformed: %d', (int) $summary['transformed'] ) );
			WP_CLI::log( sprintf( 'Skipped: %d', (int) $summary['skipped'] ) );

			$this->log_counter_map( 'Skip reasons', $summary['skip_reasons'] ?? array() );
			$this->log_counter_map( 'Listing status', $summary['status_counts'] ?? array() );
			$this->log_counter_map( 'Dropped fields', $summary['dropped_fields'] ?? array() );

			if ( $dry_run ) {
				WP_CLI::success( 'Dry run complete. Nothing was sent.' );
				return;
			}

			$send = is_array( $summary['send'] ?? null ) ? $summary['send'] : array();

			if ( empty( $send ) ) {
				WP_CLI::warning( 'Nothing to send after filtering; no listings were uploaded.' );
				return;
			}

			WP_CLI::log( sprintf( 'external_source: %s', (string) $summary['external_source'] ) );
			WP_CLI::log( sprintf( 'auto_publish_approved: %s', ! empty( $summary['auto_publish_approved'] ) ? 'on' : 'off' ) );
			WP_CLI::log( sprintf( 'Batches: %d', (int) ( $send['batches'] ?? 0 ) ) );
			WP_CLI::log( sprintf( 'Created: %d', (int) ( $send['created'] ?? 0 ) ) );
			WP_CLI::log( sprintf( 'Updated: %d', (int) ( $send['updated'] ?? 0 ) ) );
			WP_CLI::log( sprintf( 'Errored: %d', (int) ( $send['errored'] ?? 0 ) ) );

			$examples    = is_array( $send['error_examples'] ?? null ) ? $send['error_examples'] : array();
			$http_errors = is_array( $send['http_errors'] ?? null ) ? $send['http_errors'] : array();
			$errored     = (int) ( $send['errored'] ?? 0 );

			$this->log_row_error_examples( $examples );
			$this->log_notices(
				is_array( $send['options_created'] ?? null ) ? $send['options_created'] : array(),
				is_array( $send['other_notices'] ?? null ) ? $send['other_notices'] : array()
			);
			$this->log_warnings(
				(int) ( $send['warnings'] ?? 0 ),
				is_array( $send['warning_examples'] ?? null ) ? $send['warning_examples'] : array()
			);

			if ( ! empty( $http_errors ) ) {
				WP_CLI::warning( sprintf( '%d batch(es) failed at the HTTP level:', count( $http_errors ) ) );
				$this->log_http_errors( $http_errors );
			}

			if ( $errored > 0 ) {
				WP_CLI::warning( sprintf( 'Completed with %d per-row error(s).', $errored ) );
				return;
			}

			WP_CLI::success(
				sprintf(
					'Sync complete: %d created, %d updated.',
					(int) ( $send['created'] ?? 0 ),
					(int) ( $send['updated'] ?? 0 )
				)
			);
		}

		/**
		 * Route a run-scoped secondary filter to the Dataverse source through
		 * its filter hook: either the raw --secondary-filter fragment, or the
		 * guided --secondary-filter-field / --secondary-filter-values pair,
		 * built and validated by
		 * `Agend_Directory_Sync_Dataverse_Source::build_secondary_filter_from_args()`
		 * so a typo fails here with a specific message rather than as a
		 * Dataverse 400 mid-run.
		 *
		 * The override replaces the saved fragment even when blank, which is
		 * how a script asks for an unfiltered run against a site whose saved
		 * settings carry a filter: `--secondary-filter=''`.
		 *
		 * @param array<string, string> $assoc_args
		 */
		private function apply_secondary_filter_args( array $assoc_args ): void {
			try {
				$fragment = Agend_Directory_Sync_Dataverse_Source::build_secondary_filter_from_args( $assoc_args );
			} catch ( RuntimeException $e ) {
				WP_CLI::error( $e->getMessage() );
				return;
			}

			$via = isset( $assoc_args['secondary-filter'] )
				? '--secondary-filter'
				: '--secondary-filter-field/--secondary-filter-values';

			$active = Agend_Directory_Sync_Source_Registry::active()->get_key();
			if ( Agend_Directory_Sync_Dataverse_Source::SOURCE_KEY !== $active ) {
				WP_CLI::warning( sprintf( '%s applies to the Microsoft Dataverse source only; the active source is "%s", so it has no effect on this run.', $via, $active ) );
			}

			add_filter(
				Agend_Directory_Sync_Dataverse_Source::SECONDARY_FILTER_HOOK,
				static function () use ( $fragment ): string {
					return $fragment;
				}
			);

			WP_CLI::log(
				'' !== $fragment
					? sprintf( 'Secondary filter: applied from %s.', $via )
					: sprintf( 'Secondary filter: cleared for this run by %s.', $via )
			);
		}

		/**
		 * Log a counter map (reason/status => count) as one indented line each.
		 *
		 * @param string             $heading
		 * @param array<string, int> $map
		 */
		private function log_counter_map( string $heading, array $map ): void {
			if ( empty( $map ) ) {
				return;
			}
			WP_CLI::log( $heading . ':' );
			foreach ( $map as $key => $count ) {
				WP_CLI::log( sprintf( '  %s: %d', (string) $key, (int) $count ) );
			}
		}

		/**
		 * Print each failed batch's message, and any per-row validation issues
		 * beneath it. Agend_Directory_Sync_Runner stamps each issue with a
		 * run-wide, 1-based listing_position (and, when known, the row's
		 * external_id) before this summary is returned, the same way the
		 * resumable job does for a browser run -- send_listings() makes one
		 * call for the whole listings set here, so its own batch_index is
		 * already run-wide and the position needs no further restamping.
		 * Formatted with Agend_Directory_Sync_Agend_Client::format_issue_line(),
		 * shared with (and covered by the same tests as) the admin result
		 * panel's equivalent, translated rendering.
		 *
		 * @param array<int, array<string, mixed>> $http_errors
		 */
		private function log_http_errors( array $http_errors ): void {
			foreach ( $http_errors as $http_error ) {
				$batch_index = (int) ( $http_error['batch_index'] ?? 0 );
				$message     = (string) ( $http_error['message'] ?? '' );

				WP_CLI::warning( sprintf( 'Batch %d: %s', $batch_index + 1, $message ) );

				$issues = is_array( $http_error['issues'] ?? null ) ? $http_error['issues'] : array();

				foreach ( $issues as $issue ) {
					if ( ! is_array( $issue ) ) {
						continue;
					}

					WP_CLI::log( '  ' . Agend_Directory_Sync_Agend_Client::format_issue_line( $issue ) );
				}
			}
		}

		/**
		 * Print each failed row example's own field-level issues (the
		 * gateway's per-row `error.fields`), the same
		 * Agend_Directory_Sync_Agend_Client::format_issue_line() shape
		 * log_http_errors() uses for a batch-level 400's issues. Absent on
		 * an older gateway's response, so nothing is printed then.
		 *
		 * @param array<int, array<string, mixed>> $examples
		 */
		private function log_row_error_examples( array $examples ): void {
			foreach ( $examples as $example ) {
				$fields = is_array( $example['fields'] ?? null ) ? $example['fields'] : array();

				foreach ( $fields as $issue ) {
					if ( ! is_array( $issue ) ) {
						continue;
					}

					WP_CLI::log( Agend_Directory_Sync_Agend_Client::format_issue_line( $issue ) );
				}
			}
		}

		/**
		 * Log the "New options were created" notices a run's rows carried,
		 * one line per `custom_fields.<key>` path, plus a count for any other
		 * notice code the gateway sent. Absent on an older gateway's
		 * response, so both are empty and nothing is printed then.
		 *
		 * @param array<string, array{count: int, values: array<int, string>}> $options_created
		 * @param array<string, int>                                            $other_notices
		 */
		private function log_notices( array $options_created, array $other_notices ): void {
			foreach ( $options_created as $path => $data ) {
				if ( ! is_array( $data ) ) {
					continue;
				}
				WP_CLI::log( Agend_Directory_Sync_Agend_Client::format_option_created_line( (string) $path, $data ) );
			}

			foreach ( $other_notices as $code => $count ) {
				WP_CLI::log( sprintf( 'Notice %s: %d row(s)', (string) $code, (int) $count ) );
			}
		}

		/**
		 * Log the total count of `warnings` the run's rows carried, plus its
		 * capped sanitised examples. Absent on an older gateway's response,
		 * so this is a no-op then (count 0).
		 *
		 * @param int                $warnings
		 * @param array<int, string> $warning_examples
		 */
		private function log_warnings( int $warnings, array $warning_examples ): void {
			if ( 0 === $warnings ) {
				return;
			}

			WP_CLI::warning( sprintf( '%d row(s) carried a warning from the gateway.', $warnings ) );

			foreach ( $warning_examples as $example ) {
				WP_CLI::log( '  ' . (string) $example );
			}
		}
	}
endif;

WP_CLI::add_command( 'agend-directory-sync', 'Agend_Directory_Sync_CLI_Command' );
