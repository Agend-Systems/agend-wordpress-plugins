<?php
/**
 * Transform source membership directory contacts into Agend bulk-upsert
 * listings.
 *
 * Pure functions; no I/O. Given an array of source contact rows (as
 * associative arrays) and a resolved field map, returns the Agend listings
 * payload plus a small report of why rows were skipped.
 *
 * The mapping is NOT hard-coded: every Agend target reads its source field
 * from the supplied `$field_map` (see Agend_Directory_Sync_Field_Map). The
 * defaults reproduce the original Upbeat mapping exactly, so an unconfigured
 * install behaves as before, but each target can be repointed to match a
 * different environment, or blanked to omit it entirely.
 *
 * Resolved-map default behaviour:
 * - external_id  <- map[external_id] (Upbeat's stable id by default)
 * - name         <- "first last", falls back to full, then
 *                   "Member <number>", then "Unnamed member"
 * - description  <- map[description] (when present)
 * - email        <- map[email] (when present)
 * - phone        <- map[phone], falls back to map[phone_fallback]
 * - status       <- "approved" when both the eligibility AND opt-in flag
 *                   sources are true (a blank flag source counts as true),
 *                   otherwise "suspended" (the row is preserved but hidden
 *                   from the public directory until the source flags flip)
 * - category_slugs <- [slug(map[category])] when present
 * - tag_slugs    <- [slug(map[tag])] when present
 * - badge_slugs  <- map(slug, map[badges]) when present
 * - hero_image_url <- map[hero_image] (when present, valid URL, <=1000 chars)
 * - custom_fields  <- the resolved custom_fields map, plus designations from
 *                    the badges source
 * - external_metadata <- contributed by the active source (Decision 2.7); when
 *                    no source is supplied (a direct caller), falls back to
 *                    the original Upbeat keys (upbeat_unique_id,
 *                    upbeat_date_modified, synced_at), still resolved through
 *                    the field map and path resolver rather than a hardcoded
 *                    `dateModified` read.
 *
 * Every source-field lookup (`source()`, `raw_value()`, `flag()`, the
 * location slot sub-fields, and the `date_modified` metadata source) resolves
 * through Agend_Directory_Sync_Path_Resolver, so a nested source field such as
 * `contact.email` or `addresses.0.suburb` maps without code
 * (SPEC-DIR-20260731 US-3.1). The transformer stays pure: no I/O, no option
 * reads; the resolver is a pure function over the data already passed in.
 *
 * A configured source may also be a concatenation template, e.g.
 * `{name_first} {name_last}` or `{addresses.0.unit}/{addresses.0.street}`
 * (US-3.2). Every target that reads a string source — core fields, custom
 * fields, and the string location sub-fields — resolves templates through
 * `resolve_configured()`. `flag()` stays path-only: a boolean gate has no
 * sensible template meaning.
 *
 * Residential address fields are intentionally NOT mapped. The directory is
 * professional; residential addresses are sensitive and would need an
 * explicit operator decision before being published.
 *
 * @package Agend_Directory_Sync
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Agend_Directory_Sync_Listing_Transformer' ) ) :
	final class Agend_Directory_Sync_Listing_Transformer {

		public const SKIP_REASON_MISSING_EXTERNAL_ID = 'missing_external_id';

		/**
		 * Reserved contact key under which a child list's grouped, reduced
		 * rows are attached before `transform_all()` runs
		 * (SPEC-DIR-20260930-directory-item-list-field US-2.1 AC4):
		 * `$contact[CHILD_ROWS_KEY][$target] = array<int, array<string,mixed>>`.
		 * Chosen to be exceedingly unlikely to collide with a real source
		 * field name. Public so the runner (the only writer of this key) and
		 * tests share one literal rather than two copies drifting apart.
		 */
		public const CHILD_ROWS_KEY = '__agend_child_list_rows';

		/**
		 * Status assigned when the member is both eligible AND has opted in to
		 * the directory. Combined with `auto_publish_approved` on the
		 * bulk-upsert call this makes the listing visible on the public
		 * directory.
		 */
		public const STATUS_VISIBLE = 'approved';

		/**
		 * Status assigned when the member has lost eligibility OR opted out,
		 * and neither flag is in map mode. The row is preserved (no delete)
		 * but hidden from the public directory because the frontend requires
		 * `status = 'approved'`. Flips back to visible automatically on the
		 * next sync if the source flags flip back.
		 */
		public const STATUS_HIDDEN = 'suspended';

		/**
		 * Status assigned when the most restrictive resolved outcome across
		 * the two flags is `draft` AND at least one flag is in map mode.
		 * Same "kept but hidden" semantics as STATUS_HIDDEN, but a distinct
		 * status string so a map-mode "draft" outcome is distinguishable from
		 * the legacy truthy-only `suspended` status.
		 */
		public const STATUS_PENDING = 'pending';

		/**
		 * Maximum distinct unmapped values tracked per flag in
		 * `unmapped_flag_values`. Past this the counter for an already-seen
		 * value keeps incrementing but no new distinct value is added,
		 * keeping the admin-page transient bounded on large syncs.
		 */
		public const MAX_UNMAPPED_FLAG_VALUES = 20;

		/**
		 * The Dataverse/OData annotation suffix carrying a field's
		 * human-readable label alongside its raw value (e.g. an option-set
		 * code). A flag in map mode matches against both the raw value and
		 * this label (SPEC-DIR-20260731 flag key map feature).
		 */
		private const LABEL_ANNOTATION_SUFFIX = '@OData.Community.Display.V1.FormattedValue';

		/**
		 * Maximum accepted length for the Agend `phone` field. Both the gateway
		 * Zod schema and the underlying business_listings.phone column are
		 * varchar(50); anything longer is dropped on the way out rather than
		 * truncated, so the directory never shows a half-number.
		 */
		public const MAX_PHONE_LENGTH = 50;

		/**
		 * Maximum accepted length for the Agend `hero_image_url` field. Both
		 * the gateway Zod schema and the underlying
		 * business_listings.hero_image_url column are varchar(1000); anything
		 * longer is dropped rather than truncated, since a truncated URL is
		 * unusable.
		 */
		public const MAX_HERO_IMAGE_URL_LENGTH = 1000;

		/**
		 * Maximum number of identifying examples captured per drop reason. Past
		 * this the counter still increments but no extra example is recorded,
		 * keeping the admin-page transient bounded on large syncs.
		 */
		public const MAX_DROPPED_FIELD_EXAMPLES = 50;

		/**
		 * Filter, dedupe and transform an array of source contacts.
		 *
		 * @param array<int, array<string, mixed>>                                $contacts  Source contact rows.
		 * @param array{core: array<string,string>, custom_fields: array<string,string>}|null $field_map Resolved field map; defaults applied when null.
		 * @param Agend_Directory_Sync_Source|null                                $source    Active source, for its external_metadata contribution
		 *                                                                                    (Decision 2.7). Null falls back to the original Upbeat
		 *                                                                                    keys for direct callers (back-compat).
		 *
		 * @return array{
		 *     listings: array<int, array<string, mixed>>,
		 *     skipped: int,
		 *     skip_reasons: array<string, int>,
		 *     duplicate_external_ids: int,
		 *     dropped_fields: array<string, int>,
		 *     dropped_field_examples: array<string, array<int, array{external_id: string, fullname: string}>>,
		 *     status_counts: array<string, int>,
		 *     unmapped_flag_values: array<string, array<string, int>>
		 * }
		 */
		public static function transform_all( array $contacts, ?array $field_map = null, ?Agend_Directory_Sync_Source $source = null ): array {
			$field_map              = self::normalise_map( $field_map );
			$by_external_id         = array();
			$skipped                = 0;
			$skip_reasons           = array();
			$duplicates             = 0;
			$dropped_fields         = array();
			$dropped_field_examples = array();
			$status_counts          = array();
			$unmapped_flag_values   = array();

			foreach ( $contacts as $contact ) {
				if ( ! is_array( $contact ) ) {
					continue;
				}

				$skip_reason = self::should_skip( $contact, $field_map );
				if ( null !== $skip_reason ) {
					$skipped++;
					$skip_reasons[ $skip_reason ] = ( $skip_reasons[ $skip_reason ] ?? 0 ) + 1;
					continue;
				}

				$listing     = self::transform_one( $contact, $field_map, $dropped_fields, $dropped_field_examples, $unmapped_flag_values, $source );
				$external_id = $listing['external_id'];
				$status      = (string) ( $listing['status'] ?? '' );

				$status_counts[ $status ] = ( $status_counts[ $status ] ?? 0 ) + 1;

				if ( isset( $by_external_id[ $external_id ] ) ) {
					$duplicates++;
				}

				// Last-write-wins on duplicates. The source shouldn't issue
				// duplicates for the same external id but we guard anyway,
				// since the Agend API rejects intra-batch conflicts.
				$by_external_id[ $external_id ] = $listing;
			}

			return array(
				'listings'               => array_values( $by_external_id ),
				'skipped'                => $skipped,
				'skip_reasons'           => $skip_reasons,
				'duplicate_external_ids' => $duplicates,
				'dropped_fields'         => $dropped_fields,
				'dropped_field_examples' => $dropped_field_examples,
				'status_counts'          => $status_counts,
				'unmapped_flag_values'   => $unmapped_flag_values,
			);
		}

		/**
		 * Fill in any missing map sections from the defaults so callers can
		 * pass a partial map (or none) safely.
		 *
		 * @param array{core?: array<string,string>, custom_fields?: array<string,string>}|null $field_map
		 *
		 * @return array{core: array<string,string>, custom_fields: array<string,string>}
		 */
		private static function normalise_map( ?array $field_map ): array {
			$defaults = class_exists( 'Agend_Directory_Sync_Field_Map' )
				? Agend_Directory_Sync_Field_Map::defaults()
				: array( 'core' => array(), 'custom_fields' => array() );

			if ( null === $field_map ) {
				return $defaults;
			}

			$core          = isset( $field_map['core'] ) && is_array( $field_map['core'] )
				? array_merge( $defaults['core'], $field_map['core'] )
				: $defaults['core'];
			$custom_fields = isset( $field_map['custom_fields'] ) && is_array( $field_map['custom_fields'] )
				? $field_map['custom_fields']
				: $defaults['custom_fields'];
			if ( isset( $field_map['primary_location'] ) && is_array( $field_map['primary_location'] ) ) {
				$primary_location     = $field_map['primary_location'];
				$additional_locations = isset( $field_map['additional_locations'] ) && is_array( $field_map['additional_locations'] )
					? $field_map['additional_locations']
					: array();
			} elseif ( isset( $field_map['locations'] ) && is_array( $field_map['locations'] ) && class_exists( 'Agend_Directory_Sync_Field_Map' ) ) {
				// A caller still passing the flat pre-split slot list.
				$migrated             = Agend_Directory_Sync_Field_Map::migrate_legacy_locations( $field_map['locations'] );
				$primary_location     = $migrated['primary_location'];
				$additional_locations = $migrated['additional_locations'];
			} else {
				$primary_location     = $defaults['primary_location'] ?? array();
				$additional_locations = array();
			}
			$flags         = isset( $field_map['flags'] ) && is_array( $field_map['flags'] )
				? $field_map['flags']
				: ( $defaults['flags'] ?? array() );
			$child_lists   = isset( $field_map['child_lists'] ) && is_array( $field_map['child_lists'] )
				? $field_map['child_lists']
				: ( $defaults['child_lists'] ?? array() );

			return array(
				'core'                 => $core,
				'custom_fields'        => $custom_fields,
				'primary_location'     => $primary_location,
				'additional_locations' => $additional_locations,
				'flags'                => $flags,
				'child_lists'          => $child_lists,
			);
		}

		/**
		 * Read a source field from a contact using the configured source name
		 * (a plain field name or a dot-path, resolved via
		 * Agend_Directory_Sync_Path_Resolver). A blank source name yields ''
		 * so the target is omitted.
		 *
		 * Public so a source's `get_external_metadata()` implementation
		 * (e.g. Agend_Directory_Sync_Upbeat_Client) can resolve a field-map
		 * source the same way the transformer does, without a duplicate
		 * implementation (SPEC-DIR-20260731 Decision 2.3, US-1.1 criterion 8).
		 *
		 * @param array<string, mixed>  $contact
		 * @param array<string, string> $core
		 * @param string                $key
		 */
		public static function resolve_source_field( array $contact, array $core, string $key ): string {
			$field = (string) ( $core[ $key ] ?? '' );
			if ( '' === $field ) {
				return '';
			}
			return self::stringy( self::resolve_configured( $contact, $field ) );
		}

		/**
		 * Resolve a configured source value, which is either a plain source
		 * field / dot-path or a concatenation template (US-3.2). A blank
		 * field yields ''.
		 *
		 * @param array<string, mixed> $contact
		 *
		 * @return mixed
		 */
		private static function resolve_configured( array $contact, string $field ) {
			if ( '' === $field ) {
				return '';
			}
			if ( Agend_Directory_Sync_Path_Resolver::is_template( $field ) ) {
				return Agend_Directory_Sync_Path_Resolver::resolve_template( $contact, $field );
			}
			return Agend_Directory_Sync_Path_Resolver::resolve( $contact, $field );
		}

		/**
		 * Alias of resolve_source_field() kept for readability at call sites
		 * within this class.
		 *
		 * @param array<string, mixed>  $contact
		 * @param array<string, string> $core
		 * @param string                $key
		 */
		private static function source( array $contact, array $core, string $key ): string {
			return self::resolve_source_field( $contact, $core, $key );
		}

		/**
		 * Decide whether to skip a contact entirely. Only a missing external id
		 * is a skip condition. Eligibility / opt-in state are status decisions
		 * handled by `resolve_status()` so a member who later regains
		 * eligibility flips back to visible on the next sync without a delete.
		 *
		 * @param array<string, mixed>                                  $contact
		 * @param array{core: array<string,string>, custom_fields: array<string,string>} $field_map
		 */
		private static function should_skip( array $contact, array $field_map ): ?string {
			$external_id = self::source( $contact, $field_map['core'], 'external_id' );
			if ( '' === $external_id ) {
				return self::SKIP_REASON_MISSING_EXTERNAL_ID;
			}

			return null;
		}

		/**
		 * Resolve the Agend listing status from the two visibility flag
		 * sources.
		 *
		 * Each flag independently reads in one of two modes (flag key map
		 * feature):
		 * - truthy (default, back-compat): the source is coerced to a
		 *   boolean with `truthy()`, honouring the per-flag invert setting.
		 *   True ranks as OUTCOME_PUBLISHED, false as OUTCOME_DRAFT.
		 * - map: the source value is matched against a configured list of
		 *   value => outcome rows instead (see `flag_outcome_map()`).
		 *
		 * The most restrictive of the two flags' outcomes wins (published <
		 * draft in restrictiveness). When NEITHER flag is in map mode this
		 * collapses to exactly today's two-status behaviour: both flags
		 * true is `approved`, otherwise `suspended`. The existing
		 * FlagInvertTest / FieldMapFlagsTest / FlagTruthyCoercionTest suites
		 * assert this stays byte-for-byte identical. Only once at least one
		 * flag is in map mode does a `draft` outcome send `pending` instead.
		 *
		 * @param array<string, mixed>                                                                                        $contact
		 * @param array{core: array<string,string>, custom_fields: array<string,string>, flags: array<string,mixed>} $field_map
		 * @param array<string, array<string, int>>                                                                   $unmapped_flag_values Mutated counter of unmapped map-mode values, per flag.
		 */
		private static function resolve_status( array $contact, array $field_map, array &$unmapped_flag_values ): string {
			$flags = $field_map['flags'] ?? array();
			$core  = $field_map['core'];

			$eligible_mapped = self::flag_is_mapped( $flags, 'eligible_flag' );
			$opt_in_mapped   = self::flag_is_mapped( $flags, 'opt_in_flag' );

			$eligible_outcome = self::flag_outcome( $contact, $core, 'eligible_flag', $flags, $unmapped_flag_values );
			$opt_in_outcome   = self::flag_outcome( $contact, $core, 'opt_in_flag', $flags, $unmapped_flag_values );

			$outcome = self::most_restrictive_outcome( array( $eligible_outcome, $opt_in_outcome ) );

			if ( ! $eligible_mapped && ! $opt_in_mapped ) {
				// Pure back-compat path: neither flag has a map configured.
				return Agend_Directory_Sync_Field_Map::OUTCOME_PUBLISHED === $outcome
					? self::STATUS_VISIBLE
					: self::STATUS_HIDDEN;
			}

			return Agend_Directory_Sync_Field_Map::OUTCOME_PUBLISHED === $outcome
				? self::STATUS_VISIBLE
				: self::STATUS_PENDING;
		}

		/**
		 * Whether a flag is configured for map mode.
		 *
		 * @param array<string, mixed> $flags
		 */
		private static function flag_is_mapped( array $flags, string $key ): bool {
			$mode = $flags[ $key . '_mode' ] ?? Agend_Directory_Sync_Field_Map::FLAG_MODE_TRUTHY;
			return Agend_Directory_Sync_Field_Map::FLAG_MODE_MAP === $mode;
		}

		/**
		 * Resolve a single flag's outcome, dispatching to truthy or map mode.
		 *
		 * @param array<string, mixed>              $contact
		 * @param array<string, string>              $core
		 * @param array<string, mixed>               $flags
		 * @param array<string, array<string, int>>  $unmapped_flag_values Mutated.
		 */
		private static function flag_outcome( array $contact, array $core, string $key, array $flags, array &$unmapped_flag_values ): string {
			if ( ! self::flag_is_mapped( $flags, $key ) ) {
				$invert = ! empty( $flags[ $key . '_invert' ] );
				$value  = self::flag( $contact, $core, $key, $invert );
				return $value ? Agend_Directory_Sync_Field_Map::OUTCOME_PUBLISHED : Agend_Directory_Sync_Field_Map::OUTCOME_DRAFT;
			}

			return self::flag_outcome_map( $contact, $core, $key, $flags, $unmapped_flag_values );
		}

		/**
		 * Resolve a map-mode flag's outcome. A blank configured source means
		 * no gate (same as truthy mode's blank-source case): always
		 * OUTCOME_PUBLISHED. Otherwise the resolved value (or, for a list
		 * value, each item) is compared case-insensitively, after trim,
		 * against both the raw map entry value and its label: the
		 * Dataverse/OData FormattedValue annotation sibling, resolved
		 * through the same path. A value matching no entry (including a
		 * missing or empty resolved value) is unmapped: it takes the map's
		 * default outcome and is recorded in `$unmapped_flag_values`. For a
		 * list, the most restrictive of the matched items' outcomes wins;
		 * an unmatched item is still recorded as unmapped even when another
		 * item in the same list did match.
		 *
		 * @param array<string, mixed>              $contact
		 * @param array<string, string>              $core
		 * @param array<string, mixed>               $flags
		 * @param array<string, array<string, int>>  $unmapped_flag_values Mutated.
		 */
		private static function flag_outcome_map( array $contact, array $core, string $key, array $flags, array &$unmapped_flag_values ): string {
			$field = (string) ( $core[ $key ] ?? '' );
			if ( '' === $field ) {
				return Agend_Directory_Sync_Field_Map::OUTCOME_PUBLISHED;
			}

			$map     = isset( $flags[ $key . '_map' ] ) && is_array( $flags[ $key . '_map' ] ) ? $flags[ $key . '_map' ] : array();
			$default = self::sanitize_outcome( $flags[ $key . '_map_default' ] ?? null );

			$raw_value   = Agend_Directory_Sync_Path_Resolver::resolve( $contact, $field );
			$label_value = Agend_Directory_Sync_Path_Resolver::resolve( $contact, $field . self::LABEL_ANNOTATION_SUFFIX );

			$raw_entries   = is_array( $raw_value ) ? $raw_value : array( $raw_value );
			$label_entries = is_array( $label_value ) ? $label_value : array( $label_value );
			if ( empty( $raw_entries ) ) {
				// An empty list, or a missing/empty scalar, is still one
				// unmapped occurrence to report, never silently skipped.
				$raw_entries = array( null );
			}

			$matched = array();
			foreach ( $raw_entries as $index => $raw_entry ) {
				$label_entry = $label_entries[ $index ] ?? null;
				$outcome     = self::match_flag_map_entry( $map, $raw_entry, $label_entry );

				if ( null !== $outcome ) {
					$matched[] = $outcome;
					continue;
				}

				self::record_unmapped_flag_value( $unmapped_flag_values, $key, self::flag_match_string( $raw_entry ) );
			}

			return empty( $matched ) ? $default : self::most_restrictive_outcome( $matched );
		}

		/**
		 * Find the first map row whose value matches `$raw` or `$label`
		 * (case-insensitive, trimmed), returning its sanitised outcome, or
		 * null when nothing matches.
		 *
		 * @param array<int, array{value?: mixed, outcome?: mixed}> $map
		 * @param mixed                                             $raw
		 * @param mixed                                             $label
		 */
		private static function match_flag_map_entry( array $map, $raw, $label ): ?string {
			$raw_string   = self::flag_match_string( $raw );
			$label_string = self::flag_match_string( $label );

			foreach ( $map as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}

				$entry_value = self::flag_match_string( $row['value'] ?? '' );
				if ( '' === $entry_value ) {
					continue;
				}

				$matches_raw   = '' !== $raw_string && 0 === strcasecmp( $entry_value, $raw_string );
				$matches_label = '' !== $label_string && 0 === strcasecmp( $entry_value, $label_string );

				if ( $matches_raw || $matches_label ) {
					return self::sanitize_outcome( $row['outcome'] ?? null );
				}
			}

			return null;
		}

		/**
		 * Coerce a resolved flag/label value to its comparison string.
		 * Scalars compare as strings (so int 1 matches "1"); booleans
		 * stringify as "true"/"false" (SPEC-DIR-20260731 flag key map
		 * feature), matching how an operator would type them into the map.
		 * Non-scalars (null, arrays) yield '': no match.
		 *
		 * @param mixed $value
		 */
		private static function flag_match_string( $value ): string {
			if ( is_bool( $value ) ) {
				return $value ? 'true' : 'false';
			}
			if ( is_string( $value ) ) {
				return trim( $value );
			}
			if ( is_scalar( $value ) ) {
				return trim( (string) $value );
			}
			return '';
		}

		/**
		 * Validate an outcome value against the outcomes actually offered
		 * today. Anything else, including OUTCOME_SKIP, which is reserved
		 * but not offered yet, falls back to OUTCOME_DRAFT, the safer
		 * (more restrictive) choice. Defensive: the transformer accepts a
		 * raw, unsanitised `$field_map` from callers/tests, so it cannot
		 * rely on Agend_Directory_Sync_Field_Map::sanitize_flags() having
		 * already run.
		 *
		 * @param mixed $value
		 */
		private static function sanitize_outcome( $value ): string {
			return Agend_Directory_Sync_Field_Map::OUTCOME_PUBLISHED === $value
				? Agend_Directory_Sync_Field_Map::OUTCOME_PUBLISHED
				: Agend_Directory_Sync_Field_Map::OUTCOME_DRAFT;
		}

		/**
		 * The most restrictive outcome present in `$outcomes`, per
		 * Agend_Directory_Sync_Field_Map::OUTCOME_RANKING. Defaults to the
		 * least restrictive (published) when `$outcomes` is empty or
		 * contains nothing recognised.
		 *
		 * @param array<int, string> $outcomes
		 */
		private static function most_restrictive_outcome( array $outcomes ): string {
			$ranking     = Agend_Directory_Sync_Field_Map::OUTCOME_RANKING;
			$best_index  = 0;
			$best        = $ranking[0];

			foreach ( $outcomes as $outcome ) {
				$index = array_search( $outcome, $ranking, true );
				if ( false === $index || $index <= $best_index ) {
					continue;
				}
				$best_index = $index;
				$best       = $outcome;
			}

			return $best;
		}

		/**
		 * Record one unmapped map-mode value for a flag, capped at
		 * MAX_UNMAPPED_FLAG_VALUES distinct values per flag. Past the cap, a
		 * value already tracked keeps incrementing; a brand-new distinct
		 * value is dropped.
		 *
		 * @param array<string, array<string, int>> $unmapped_flag_values Mutated.
		 */
		private static function record_unmapped_flag_value( array &$unmapped_flag_values, string $flag_key, string $value_string ): void {
			if ( ! isset( $unmapped_flag_values[ $flag_key ] ) ) {
				$unmapped_flag_values[ $flag_key ] = array();
			}

			$bucket = &$unmapped_flag_values[ $flag_key ];

			if ( ! isset( $bucket[ $value_string ] ) && count( $bucket ) >= self::MAX_UNMAPPED_FLAG_VALUES ) {
				return;
			}

			$bucket[ $value_string ] = ( $bucket[ $value_string ] ?? 0 ) + 1;
		}

		/**
		 * Read a truthy/falsey flag source, resolved via the path resolver
		 * and coerced with `truthy()`. A blank source name counts as true
		 * (the environment has no such gate) and `$invert` is NOT applied to
		 * that short-circuit — there is no gate to flip. Otherwise the
		 * resolved value is coerced and, when `$invert` is true, negated.
		 *
		 * With invert on, an unresolved/missing flag coerces to false and
		 * then inverts to true (visible): correct for a hide-when-true
		 * source, where a missing flag means "nothing says to hide this
		 * row". Path-only, deliberately: a concatenation template
		 * (US-3.2) always yields a string, and while `truthy()` can coerce a
		 * string, templating a flag source composed of several fields has no
		 * sensible meaning and is not supported.
		 *
		 * @param array<string, mixed>  $contact
		 * @param array<string, string> $core
		 * @param string                $key
		 */
		private static function flag( array $contact, array $core, string $key, bool $invert = false ): bool {
			$field = (string) ( $core[ $key ] ?? '' );
			if ( '' === $field ) {
				return true;
			}

			$value = self::truthy( Agend_Directory_Sync_Path_Resolver::resolve( $contact, $field ) );
			return $invert ? ! $value : $value;
		}

		/**
		 * Coerce a resolved flag value to a boolean using truthy/falsey
		 * semantics rather than a strict `true ===` check (SPEC-DIR-20260731
		 * US-3.3), so a source that stores "true"/"false", "yes"/"no",
		 * "1"/"0", or on/off strings gates visibility without the client
		 * having to normalise it upstream.
		 *
		 * - bool: itself.
		 * - null / array / any other non-scalar (including an unresolved
		 *   path, which resolves to null): false.
		 * - case-insensitive string tokens 'false', 'no', 'n', 'off', '0', ''
		 *   (after trim): false.
		 * - numeric value: false only for zero (0, 0.0, '0'); any other
		 *   number is true.
		 * - any other non-empty scalar string: true (PHP-style truthiness,
		 *   so '1', 'true', 'yes', 'y', 'on' are all true without needing an
		 *   allow-list of their own).
		 *
		 * @param mixed $value
		 */
		private static function truthy( $value ): bool {
			if ( is_bool( $value ) ) {
				return $value;
			}

			if ( ! is_scalar( $value ) ) {
				return false;
			}

			if ( is_string( $value ) ) {
				$trimmed = trim( $value );
				if ( in_array( strtolower( $trimmed ), array( 'false', 'no', 'n', 'off', '0', '' ), true ) ) {
					return false;
				}
				if ( is_numeric( $trimmed ) ) {
					return 0.0 !== (float) $trimmed;
				}
				return true;
			}

			// int|float.
			return 0.0 !== (float) $value;
		}

		/**
		 * Transform a single source contact into an Agend listing payload.
		 *
		 * @param array<string, mixed>                                              $contact
		 * @param array{core: array<string,string>, custom_fields: array<string,string>} $field_map
		 * @param array<string, int>                                                $dropped_fields         Mutated counter of fields
		 *                                                                                                  dropped because they fail a
		 *                                                                                                  length / format check.
		 * @param array<string, array<int, array{external_id: string, fullname: string}>> $dropped_field_examples Mutated map of identifying
		 *                                                                                                    details for the first N rows
		 *                                                                                                    affected by each drop reason.
		 * @param array<string, array<string, int>>                                 $unmapped_flag_values   Mutated counter of unmapped
		 *                                                                                                    map-mode flag values, per flag.
		 * @param Agend_Directory_Sync_Source|null                                  $source                 Active source, for its
		 *                                                                                                    external_metadata contribution.
		 *                                                                                                    Null falls back to the original
		 *                                                                                                    Upbeat keys (back-compat).
		 *
		 * @return array<string, mixed>
		 */
		private static function transform_one(
			array $contact,
			array $field_map,
			array &$dropped_fields,
			array &$dropped_field_examples,
			array &$unmapped_flag_values,
			?Agend_Directory_Sync_Source $source = null
		): array {
			$core = $field_map['core'];

			$listing = array(
				'external_id' => self::source( $contact, $core, 'external_id' ),
				'name'        => self::build_name( $contact, $core ),
				'status'      => self::resolve_status( $contact, $field_map, $unmapped_flag_values ),
			);

			$description = self::source( $contact, $core, 'description' );
			if ( '' !== $description ) {
				$listing['description'] = $description;
			}

			$email = self::source( $contact, $core, 'email' );
			if ( '' !== $email ) {
				$listing['email'] = $email;
			}

			$phone = self::source( $contact, $core, 'phone' );
			if ( '' === $phone ) {
				$phone = self::source( $contact, $core, 'phone_fallback' );
			}
			if ( '' !== $phone ) {
				if ( strlen( $phone ) > self::MAX_PHONE_LENGTH ) {
					self::record_drop( $dropped_fields, $dropped_field_examples, 'phone_too_long', $contact, $core );
				} else {
					$listing['phone'] = $phone;
				}
			}

			$profile_image_url = self::source( $contact, $core, 'hero_image' );
			if ( '' !== $profile_image_url ) {
				if ( strlen( $profile_image_url ) > self::MAX_HERO_IMAGE_URL_LENGTH ) {
					self::record_drop( $dropped_fields, $dropped_field_examples, 'hero_image_url_too_long', $contact, $core );
				} elseif ( false === filter_var( $profile_image_url, FILTER_VALIDATE_URL ) ) {
					self::record_drop( $dropped_fields, $dropped_field_examples, 'hero_image_url_invalid', $contact, $core );
				} else {
					$listing['hero_image_url'] = $profile_image_url;
				}
			}

			$category_slugs = self::collect_slugs( array( self::raw_value( $contact, $core, 'category' ) ) );
			if ( ! empty( $category_slugs ) ) {
				$listing['category_slugs'] = $category_slugs;
			}

			$tag_slugs = self::collect_slugs( array( self::raw_value( $contact, $core, 'tag' ) ) );
			if ( ! empty( $tag_slugs ) ) {
				$listing['tag_slugs'] = $tag_slugs;
			}

			$designations = self::raw_value( $contact, $core, 'badges' );
			if ( is_array( $designations ) ) {
				$badge_slugs = self::collect_slugs( $designations );
				if ( ! empty( $badge_slugs ) ) {
					$listing['badge_slugs'] = $badge_slugs;
				}
			}

			$custom_fields = self::build_custom_fields( $contact, $field_map );
			if ( ! empty( $custom_fields ) ) {
				$listing['custom_fields'] = $custom_fields;
			}

			$locations = self::build_locations( $contact, $field_map );
			if ( ! empty( $locations ) ) {
				$listing['locations'] = $locations;
			}

			// The external_metadata block is contributed by the active source
			// (Decision 2.7), so the transformer stays source-neutral. A
			// direct caller passing no source (back-compat) gets the
			// original Upbeat keys, still resolved through the field map and
			// path resolver rather than a hardcoded `dateModified` read
			// (US-3.1 criterion 5) — identical output to
			// Agend_Directory_Sync_Upbeat_Client::get_external_metadata().
			$listing['external_metadata'] = null !== $source
				? $source->get_external_metadata( $contact, $core )
				: array(
					'upbeat_unique_id'     => self::source( $contact, $core, 'external_id' ),
					'upbeat_date_modified' => self::source( $contact, $core, 'date_modified' ),
					'synced_at'            => gmdate( 'c' ),
				);

			/**
			 * Filter the transformed Agend listing payload for a single source
			 * contact. Use this to extend or override the mapping in client
			 * code without forking this plugin.
			 *
			 * @param array<string, mixed> $listing Transformed Agend listing.
			 * @param array<string, mixed> $contact Original source contact row.
			 */
			return (array) apply_filters( 'agend_directory_sync_listing_payload', $listing, $contact );
		}

		/**
		 * Return a source value verbatim (not stringified), resolved via the
		 * path resolver (or the template resolver — US-3.2), so array-shaped
		 * sources such as the badges list survive. A blank source name, or a
		 * path that fails to resolve, yields null. A template source always
		 * yields a string, so a template used for `badges` resolves no badge
		 * slugs (badges expects an array) — this is a known, acceptable
		 * consequence of allowing templates on every source, not a bug.
		 *
		 * @param array<string, mixed>  $contact
		 * @param array<string, string> $core
		 * @param string                $key
		 *
		 * @return mixed
		 */
		private static function raw_value( array $contact, array $core, string $key ) {
			$field = (string) ( $core[ $key ] ?? '' );
			if ( '' === $field ) {
				return null;
			}
			return self::resolve_configured( $contact, $field );
		}

		/**
		 * Build the listing name with sensible fallbacks, all driven by the
		 * configured name sources.
		 *
		 * @param array<string, mixed>  $contact
		 * @param array<string, string> $core
		 */
		private static function build_name( array $contact, array $core ): string {
			$first = self::source( $contact, $core, 'name_first' );
			$last  = self::source( $contact, $core, 'name_last' );

			$name = trim( $first . ' ' . $last );
			if ( '' !== $name ) {
				return $name;
			}

			$fullname = self::source( $contact, $core, 'name_full' );
			if ( '' !== $fullname ) {
				return $fullname;
			}

			$membership_number = self::source( $contact, $core, 'name_fallback_number' );
			if ( '' !== $membership_number ) {
				return sprintf( 'Member %s', $membership_number );
			}

			return 'Unnamed member';
		}

		/**
		 * Gateway cap on locations per listing (bulkUpsertListingItemSchema).
		 */
		public const MAX_LOCATIONS_PER_LISTING = 50;

		/**
		 * Build the listing `locations` array: the primary location first, then
		 * every additional-location row. A `single` row resolves one location
		 * from individual source fields; an `array` row resolves its list and
		 * maps each item (fields read relative to the item) to one location.
		 * Locations that resolve no data are skipped and a location repeating an
		 * earlier address is dropped, so the same address is never sent twice.
		 * Exactly one location is marked primary: the primary mapping when it
		 * resolves data, otherwise the first additional location that does.
		 *
		 * @param array<string, mixed> $contact
		 * @param array<string, mixed> $field_map
		 *
		 * @return array<int, array<string, mixed>>
		 */
		private static function build_locations( array $contact, array $field_map ): array {
			$candidates = array();

			$primary_map = isset( $field_map['primary_location'] ) && is_array( $field_map['primary_location'] )
				? $field_map['primary_location']
				: array();
			$primary     = self::resolve_location( $contact, $primary_map );
			if ( null !== $primary ) {
				$candidates[] = $primary;
			}

			$rows = isset( $field_map['additional_locations'] ) && is_array( $field_map['additional_locations'] )
				? $field_map['additional_locations']
				: array();
			foreach ( $rows as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}

				if ( Agend_Directory_Sync_Field_Map::LOCATION_ROW_ARRAY !== ( $row['type'] ?? '' ) ) {
					$location = self::resolve_location( $contact, $row );
					if ( null !== $location ) {
						$candidates[] = $location;
					}
					continue;
				}

				$source = (string) ( $row['source'] ?? '' );
				if ( '' === $source ) {
					continue;
				}
				$list = Agend_Directory_Sync_Path_Resolver::resolve( $contact, $source );
				if ( ! is_array( $list ) ) {
					continue;
				}
				// A source holding one object rather than a list is one item.
				if ( array_keys( $list ) !== range( 0, count( $list ) - 1 ) ) {
					$list = array( $list );
				}
				foreach ( $list as $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}
					$location = self::resolve_location( $item, $row );
					if ( null !== $location ) {
						$candidates[] = $location;
					}
				}
			}

			$locations = array();
			$seen      = array();
			foreach ( $candidates as $location ) {
				$key = self::location_identity( $location );
				if ( isset( $seen[ $key ] ) ) {
					continue;
				}
				$seen[ $key ] = true;

				$location['is_primary'] = empty( $locations );
				$locations[]            = $location;

				if ( count( $locations ) >= self::MAX_LOCATIONS_PER_LISTING ) {
					break;
				}
			}

			return $locations;
		}

		/**
		 * Resolve one location from a mapping against a data array (the whole
		 * contact, or one list item for an array row). Returns null when no
		 * address data resolves.
		 *
		 * @param array<string, mixed>  $data
		 * @param array<string, mixed>  $map  Field => source, plus `label` and, for an array row, `label_source`.
		 *
		 * @return array<string, mixed>|null
		 */
		private static function resolve_location( array $data, array $map ): ?array {
			$location = array();

			foreach ( array( 'address_line_1', 'address_line_2', 'city', 'state', 'postcode', 'country' ) as $key ) {
				$source = (string) ( $map[ $key ] ?? '' );
				$value  = '' !== $source ? self::stringy( self::resolve_configured( $data, $source ) ) : '';
				if ( '' !== $value ) {
					$location[ $key ] = $value;
				}
			}

			foreach ( array( 'latitude', 'longitude' ) as $key ) {
				$source = (string) ( $map[ $key ] ?? '' );
				if ( '' === $source ) {
					continue;
				}
				$raw = self::resolve_configured( $data, $source );
				if ( is_numeric( $raw ) ) {
					$location[ $key ] = (float) $raw;
				}
			}

			if ( empty( $location ) ) {
				return null;
			}

			$name_source = (string) ( $map['label_source'] ?? '' );
			$name        = '' !== $name_source ? self::stringy( self::resolve_configured( $data, $name_source ) ) : '';
			if ( '' === $name ) {
				$name = self::stringy( $map['label'] ?? '' );
			}
			if ( '' !== $name ) {
				$location['name'] = $name;
			}

			return $location;
		}

		/**
		 * Identity of a location for de-duplication: the street, suburb and
		 * postcode lower-cased with everything but letters and digits removed,
		 * so "1 Main St." and "1 main st" match. A location with no address text
		 * (coordinates only) is identified by its rounded coordinates.
		 *
		 * @param array<string, mixed> $location
		 */
		private static function location_identity( array $location ): string {
			$parts = array();
			foreach ( array( 'address_line_1', 'address_line_2', 'city', 'postcode' ) as $key ) {
				$parts[] = strtolower( (string) preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $location[ $key ] ?? '' ) ) );
			}
			$text = implode( '|', $parts );

			if ( '|||' === $text && isset( $location['latitude'], $location['longitude'] ) ) {
				return sprintf( 'geo:%.5f,%.5f', (float) $location['latitude'], (float) $location['longitude'] );
			}

			return 'addr:' . $text;
		}

		/**
		 * Build the custom_fields map from the configured custom-field sources.
		 * A true/false source value is sent as a bool, so a false value is kept
		 * (a string cast would turn it into '' and drop it, deleting the key on
		 * the Agend side). Other empty values are still dropped to avoid storing
		 * useless rows. The badges source is additionally preserved verbatim
		 * under `designations`.
		 *
		 * @param array<string, mixed>                                  $contact
		 * @param array{core: array<string,string>, custom_fields: array<string,string>} $field_map
		 *
		 * @return array<string, mixed>
		 */
		private static function build_custom_fields( array $contact, array $field_map ): array {
			$custom_fields = array();

			foreach ( $field_map['custom_fields'] as $target => $source ) {
				$raw = self::resolve_configured( $contact, $source );
				if ( is_bool( $raw ) ) {
					$custom_fields[ $target ] = $raw;
					continue;
				}

				$value = self::stringy( $raw );
				if ( '' !== $value ) {
					$custom_fields[ $target ] = $value;
				}
			}

			$designations = self::raw_value( $contact, $field_map['core'], 'badges' );
			if ( is_array( $designations ) && ! empty( $designations ) ) {
				$normalised = array_values(
					array_filter(
						array_map(
							array( __CLASS__, 'stringy' ),
							$designations
						),
						static function ( $value ) {
							return '' !== $value;
						}
					)
				);
				if ( ! empty( $normalised ) ) {
					$custom_fields['designations'] = $normalised;
				}
			}

			foreach ( $field_map['child_lists'] ?? array() as $entry ) {
				$target = (string) ( $entry['target'] ?? '' );
				if ( '' === $target ) {
					continue;
				}

				$rows = $contact[ self::CHILD_ROWS_KEY ][ $target ] ?? array();
				$rows = is_array( $rows ) ? $rows : array();

				// Always set, even empty: a centre that lost every centre
				// tenant is cleared on the next sync (US-2.1 AC7), never left
				// holding a stale list because an empty array looked like "no
				// value" to the ordinary drop-empty rule above.
				$custom_fields[ $target ] = self::build_child_list_items(
					$rows,
					is_array( $entry['items'] ?? null ) ? $entry['items'] : array(),
					is_array( $entry['order_by'] ?? null ) ? $entry['order_by'] : array()
				);

				foreach ( is_array( $entry['aggregates'] ?? null ) ? $entry['aggregates'] : array() as $aggregate ) {
					$aggregate_target = (string) ( $aggregate['target'] ?? '' );
					if ( '' === $aggregate_target ) {
						continue;
					}
					$custom_fields[ $aggregate_target ] = self::compute_child_list_aggregate( $rows, $aggregate );
				}
			}

			return $custom_fields;
		}

		/**
		 * Build one child list's items from its grouped, reduced rows
		 * (SPEC-DIR-20260930-directory-item-list-field US-2.1 AC5, AC6,
		 * AC11). Each item field's source resolves via the path resolver, the
		 * same resolution the main field map uses, so a Dataverse
		 * `@OData.Community.Display.V1.FormattedValue` annotation key
		 * resolves exactly like any other declared source. A source that
		 * resolves to a numeric value is kept as a number rather than
		 * stringified, so a `number`-typed item field round-trips as a
		 * number, not a numeric string.
		 *
		 * A row that resolves no item fields at all (every configured source is
		 * missing or blank) is skipped entirely rather than added as an empty
		 * PHP array: an empty array encodes as `[]`, not `{}`, and the gateway
		 * rejects the whole listing row for it.
		 *
		 * @param array<int, array<string, mixed>> $rows
		 * @param array<string, string>            $items_map Item field key => source.
		 * @param array<int, string>               $order_by  One or two item field keys to sort by.
		 *
		 * @return array<int, array<string, mixed>>
		 */
		private static function build_child_list_items( array $rows, array $items_map, array $order_by ): array {
			$items = array();

			foreach ( $rows as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}

				$item = array();
				foreach ( $items_map as $item_key => $source ) {
					$raw = Agend_Directory_Sync_Path_Resolver::resolve( $row, (string) $source );

					if ( is_numeric( $raw ) ) {
						$item[ $item_key ] = $raw + 0;
						continue;
					}

					$value = self::stringy( $raw );
					// A null or blank-after-trim source is a missing item
					// field, not an empty string value: the key is omitted
					// rather than written as '' (US-1.2 AC8 "missing item
					// field renders empty").
					if ( '' !== $value ) {
						$item[ $item_key ] = $value;
					}
				}

				if ( empty( $item ) ) {
					continue;
				}

				$items[] = $item;
			}

			if ( ! empty( $order_by ) ) {
				usort(
					$items,
					static function ( array $a, array $b ) use ( $order_by ): int {
						foreach ( $order_by as $key ) {
							$cmp = self::compare_item_values( $a[ $key ] ?? null, $b[ $key ] ?? null );
							if ( 0 !== $cmp ) {
								return $cmp;
							}
						}
						return 0;
					}
				);
			}

			return $items;
		}

		/**
		 * Order two item field values, numerically when both are numbers,
		 * case-insensitively as strings otherwise.
		 *
		 * @param mixed $a
		 * @param mixed $b
		 */
		private static function compare_item_values( $a, $b ): int {
			if ( is_numeric( $a ) && is_numeric( $b ) ) {
				return $a <=> $b;
			}
			return strcasecmp( self::stringy( $a ), self::stringy( $b ) );
		}

		/**
		 * Compute one aggregate (`count` or `sum(<source>)`, with an optional
		 * `where <source> = <value>` clause) over a child list's grouped
		 * rows (SPEC-DIR-20260930-directory-item-list-field US-2.2 AC2 to
		 * AC5). The `where` comparison, and the value summed, are always the
		 * RAW resolved source value, never a `FormattedValue` annotation
		 * (US-2.2 business rule): comparing the formatted label would silently
		 * stop matching the day Dataverse's display language changes.
		 *
		 * @param array<int, array<string, mixed>>                                            $rows
		 * @param array{target: string, op: string, source: string, where_source: string, where_value: string} $aggregate
		 *
		 * @return int|float
		 */
		private static function compute_child_list_aggregate( array $rows, array $aggregate ) {
			$where_source = (string) ( $aggregate['where_source'] ?? '' );
			$where_value  = (string) ( $aggregate['where_value'] ?? '' );

			$matching = array();
			foreach ( $rows as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				if ( '' !== $where_source ) {
					$raw = Agend_Directory_Sync_Path_Resolver::resolve( $row, $where_source );
					if ( trim( self::stringy( $raw ) ) !== trim( $where_value ) ) {
						continue;
					}
				}
				$matching[] = $row;
			}

			if ( Agend_Directory_Sync_Field_Map::AGGREGATE_OP_SUM !== ( $aggregate['op'] ?? '' ) ) {
				return count( $matching );
			}

			$source = (string) ( $aggregate['source'] ?? '' );
			$sum    = 0;
			foreach ( $matching as $row ) {
				$raw = Agend_Directory_Sync_Path_Resolver::resolve( $row, $source );
				if ( is_numeric( $raw ) ) {
					$sum += $raw + 0;
				}
			}

			return $sum;
		}

		/**
		 * Slugify a list of values into kebab-case lowercase ASCII slugs,
		 * dropping empties and duplicates while preserving the original order.
		 *
		 * @param array<int, mixed> $values
		 *
		 * @return array<int, string>
		 */
		private static function collect_slugs( array $values ): array {
			$slugs = array();
			foreach ( $values as $value ) {
				$slug = self::slugify( self::stringy( $value ) );
				if ( '' === $slug ) {
					continue;
				}
				if ( in_array( $slug, $slugs, true ) ) {
					continue;
				}
				$slugs[] = $slug;
			}
			return $slugs;
		}

		/**
		 * Increment the counter for a drop reason and, if there's room under
		 * MAX_DROPPED_FIELD_EXAMPLES, record an identifying example so the
		 * operator can find the source row.
		 *
		 * @param array<string, int>                                                  $dropped_fields
		 * @param array<string, array<int, array{external_id: string, fullname: string}>> $dropped_field_examples
		 * @param string                                                              $reason
		 * @param array<string, mixed>                                                $contact
		 * @param array<string, string>                                               $core
		 */
		private static function record_drop(
			array &$dropped_fields,
			array &$dropped_field_examples,
			string $reason,
			array $contact,
			array $core
		): void {
			$dropped_fields[ $reason ] = ( $dropped_fields[ $reason ] ?? 0 ) + 1;

			if ( ! isset( $dropped_field_examples[ $reason ] ) ) {
				$dropped_field_examples[ $reason ] = array();
			}

			if ( count( $dropped_field_examples[ $reason ] ) >= self::MAX_DROPPED_FIELD_EXAMPLES ) {
				return;
			}

			$fullname = self::source( $contact, $core, 'name_full' );
			if ( '' === $fullname ) {
				$fullname = trim(
					self::source( $contact, $core, 'name_first' ) . ' ' . self::source( $contact, $core, 'name_last' )
				);
			}

			$dropped_field_examples[ $reason ][] = array(
				'external_id' => self::source( $contact, $core, 'external_id' ),
				'fullname'    => $fullname,
			);
		}

		/**
		 * Convert any scalar to a trimmed string, returning '' for nulls and
		 * non-scalars. Public so the custom_fields array_map can reach it.
		 *
		 * @param mixed $value
		 */
		public static function stringy( $value ): string {
			if ( is_string( $value ) ) {
				return trim( $value );
			}
			if ( is_scalar( $value ) ) {
				return trim( (string) $value );
			}
			return '';
		}

		/**
		 * Kebab-case lowercase ASCII slugifier.
		 *
		 * The Agend API expects "kebab-case, lowercase ASCII, hyphens for
		 * spaces" per the bulk-upsert brief.
		 */
		private static function slugify( string $value ): string {
			$value = strtolower( trim( $value ) );
			if ( '' === $value ) {
				return '';
			}

			// Replace non-ASCII chars first via WP's sanitize_title which
			// handles transliteration in WP environments.
			if ( function_exists( 'sanitize_title' ) ) {
				$value = sanitize_title( $value );
			} else {
				$value = preg_replace( '/[^a-z0-9]+/', '-', $value );
				$value = trim( (string) $value, '-' );
			}

			return $value;
		}
	}
endif;
