<?php
/**
 * Plugin Name:     Agend Directory Sync
 * Plugin URI:      https://www.agend.com.au
 * Update URI:      https://agend-systems.github.io/agend-wordpress-plugins/agend-directory-sync
 * Description:     Sync directory records from Upbeat, any JSON API, or Microsoft Dataverse to the Agend directory via the bulk-upsert API.
 * Author:          Iugo Pty Ltd
 * Author URI:      https://www.iugo.com.au
 * Text Domain:     agend-directory-sync
 * Version:         0.7.0
 *
 * @package         Agend_Directory_Sync
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGEND_DIRECTORY_SYNC_DIR', rtrim( plugin_dir_path( __FILE__ ), '/' ) );
define( 'AGEND_DIRECTORY_SYNC_URL', esc_url( rtrim( plugin_dir_url( __FILE__ ), '/' ) ) );

if ( ! class_exists( 'Agend_Directory_Sync' ) ) :
	/**
	 * Option-key constants only. Bootstrapping lives in
	 * agend_directory_sync_bootstrap() below, not on this class — there is no
	 * singleton/instance() and nothing extends a shared plugin-lifecycle base
	 * class. Previously this class extended iugo-membership-kiosk's
	 * Iugo_Membership_Kiosk_Plugin, whose run()/check_requirements() only
	 * loaded this plugin's own files (admin page, CLI command, source
	 * registry) once the kiosk plugin was ACTIVE — so the http_api source
	 * below could never run, regardless of configuration, on a site without
	 * the kiosk active. Do not reintroduce that base class.
	 */
	final class Agend_Directory_Sync {

		/**
		 * Option key for the Upbeat directory endpoint path. The path varies per
		 * client, so it is configurable. Blank falls back to the default
		 * `membershipDirectoryContacts`.
		 *
		 * The Agend gateway base URL and API key are NOT stored here: connecting
		 * to the gateway is owned by the agend-apps-core plugin (configured under
		 * Settings > Agend Apps), which this plugin calls via
		 * `agend_apps_directory_bulk_upsert_listings()`.
		 */
		public const OPTION_UPBEAT_ENDPOINT = 'agend_directory_sync_upbeat_endpoint';

		/**
		 * Option key for the active data source key (e.g. `upbeat`,
		 * `http_api`), resolved by Agend_Directory_Sync_Source_Registry. An
		 * unset or unknown value falls back to `upbeat`, so an existing
		 * install never changes source on upgrade (SPEC-DIR-20260731
		 * Decision 2.1).
		 */
		public const OPTION_SOURCE = 'agend_directory_sync_source';

		/**
		 * Option key for the Custom HTTP API source's settings (URL,
		 * timeout, response data path, auth mode + non-secret auth
		 * settings, pagination mode + params). One array option, sanitised
		 * as a whole (SPEC-DIR-20260731 US-2.4 criterion 2). The secrets
		 * themselves are never stored here — see
		 * AGEND_DIRECTORY_SYNC_HTTP_TOKEN and
		 * AGEND_DIRECTORY_SYNC_OAUTH_CLIENT_SECRET (Decision 2.4).
		 */
		public const OPTION_HTTP_API = 'agend_directory_sync_http_api';

		/**
		 * Option key for the Microsoft Dataverse source's settings
		 * (environment URL, entity set, FetchXML query, paging window, Entra
		 * ID app registration, headers and variables). One array option,
		 * sanitised as a whole by the source. The client secret is never
		 * stored here — it lives in the encrypted secret store, or in
		 * AGEND_DIRECTORY_SYNC_DATAVERSE_CLIENT_SECRET.
		 */
		public const OPTION_DATAVERSE = 'agend_directory_sync_dataverse';

		/**
		 * Option key for the external_source string sent with each batch.
		 */
		public const OPTION_EXTERNAL_SOURCE = 'agend_directory_sync_external_source';

		/**
		 * Option key for the boolean "auto-publish approved listings" flag.
		 * When set ('1'), bulk-upsert payloads include
		 * `auto_publish_approved: true` so Agend sets `published_at` on
		 * approved rows and they appear on the public directory.
		 */
		public const OPTION_AUTO_PUBLISH_APPROVED = 'agend_directory_sync_auto_publish_approved';

		/**
		 * Default value for external_source if the option is unset. This is the
		 * upsert key the Agend gateway matches on, alongside external_id, so it
		 * MUST stay stable for a given directory. The default is generic; each
		 * site should set its own value under Tools > Agend Directory Sync.
		 *
		 * Upgrading from a release that defaulted external_source to a fixed
		 * tenant-specific value: pin that previous value in settings BEFORE the
		 * first sync, or already-synced listings will be re-inserted as new
		 * rows instead of updated in place.
		 */
		public const DEFAULT_EXTERNAL_SOURCE = 'upbeat-directory';

		/**
		 * Default for the auto-publish flag when the option has never been
		 * saved. Defaults to true because the directory is otherwise
		 * invisible to the public.
		 */
		public const DEFAULT_AUTO_PUBLISH_APPROVED = true;
	}
endif;

/**
 * Loads includes and registers hooks. Hooked on `plugins_loaded` so
 * agend-apps-core is loaded first, matching agend-apps-core's own and
 * agend-loop-sync's bootstrap pattern. Deliberately independent of whether
 * iugo-membership-kiosk is installed or active: only the Upbeat source
 * (Agend_Directory_Sync_Upbeat_Client::is_available()) gates on it, at the
 * point it is actually asked to fetch data.
 */
function agend_directory_sync_bootstrap() {
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-secret-store.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-config.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-field-map.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/interface-source.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-path-resolver.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-upbeat-client.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-oauth-token-manager.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-http-api-source.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-dataverse-source.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-listing-transformer.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-source-registry.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-agend-client.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-sync-runner.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-sync-job.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-admin-page.php';
	require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-job-controller.php';

	// The generic HTTP API and Dataverse sources ship with this plugin, but
	// register through the same `agend_directory_sync_sources` filter a client
	// source would use (SPEC-DIR-20260731 US-2.1), rather than further
	// hard-coded entries in
	// Agend_Directory_Sync_Source_Registry::register_defaults().
	add_filter(
		'agend_directory_sync_sources',
		static function ( array $sources ): array {
			$http_api                         = new Agend_Directory_Sync_Http_Api_Source();
			$sources[ $http_api->get_key() ]  = $http_api;
			$dataverse                        = new Agend_Directory_Sync_Dataverse_Source();
			$sources[ $dataverse->get_key() ] = $dataverse;
			return $sources;
		}
	);

	// The secret store subclasses agend-apps-core's Agend_Apps_Secret_Store
	// (>= 1.3.0). Against an older apps-core the subclass never defines, and
	// running any admin/CLI path would fatal on the missing class — so
	// degrade to an admin notice and register nothing instead.
	if ( ! class_exists( 'Agend_Directory_Sync_Secret_Store' ) ) {
		add_action(
			'admin_notices',
			static function (): void {
				echo '<div class="notice notice-error"><p>';
				esc_html_e( 'Agend Directory Sync requires Agend Apps Core 1.3.0 or newer (its encrypted secret store is missing). Update the Agend Apps Core plugin.', 'agend-directory-sync' );
				echo '</p></div>';
			}
		);
		return;
	}

	// Seed the source registry now: all files are included and every other
	// plugin's add_filter() calls on `agend_directory_sync_sources` have
	// already had the chance to run during their own `plugins_loaded`
	// callback (WordPress runs all `plugins_loaded` callbacks before any
	// later hook), so this sees every registration.
	Agend_Directory_Sync_Source_Registry::register_defaults();

	Agend_Directory_Sync_Admin_Page::setup_hooks();
	Agend_Directory_Sync_Job_Controller::setup_hooks();

	// Register the WP-CLI command for unattended / server-cron runs. Loaded
	// only under WP-CLI so the command class never exists in a web request.
	// The file calls WP_CLI::add_command() on load.
	if ( defined( 'WP_CLI' ) && WP_CLI ) {
		require_once AGEND_DIRECTORY_SYNC_DIR . '/includes/class-cli-command.php';
	}
}
add_action( 'plugins_loaded', 'agend_directory_sync_bootstrap' );
