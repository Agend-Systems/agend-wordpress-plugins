<?php
/**
 * Cache manager class.
 *
 * @package Agend_Apps_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages transient-based caching for Agend API responses.
 *
 * All transient keys are prefixed with `agend_apps_` to prevent collisions.
 * Cart transients use identity-scoped keys and must only be cleared individually
 * during normal operation — wildcard clearing is reserved for the admin UI.
 */
class Agend_Apps_Cache {

	/**
	 * Map of all cacheable endpoint keys with their labels and default TTLs.
	 *
	 * An entry may carry an optional `description`, shown under its label on the
	 * Cache tab and beside its TTL field. It is for a key whose use is not
	 * obvious from the label, such as one a sibling plugin owns the cache for.
	 *
	 * @var array<string, array{label: string, default_ttl: int, description?: string}>
	 */
	private static $keys = array(
		'cart_get'                 => array(
			'label'       => 'Cart Session',
			'default_ttl' => 60,
		),
		'cart_get_anonymous'       => array(
			'label'       => 'Anonymous Cart',
			'default_ttl' => 30,
		),
		'directory_listings'       => array(
			'label'       => 'Directory Listings',
			'default_ttl' => 300,
		),
		'directory_listing_single' => array(
			'label'       => 'Single Listing',
			'default_ttl' => 300,
		),
		'directory_categories'     => array(
			'label'       => 'Categories',
			'default_ttl' => 600,
		),
		'directory_search'         => array(
			'label'       => 'Directory Search',
			'default_ttl' => 120,
		),
		'directory_facets'         => array(
			'label'       => 'Directory Filter Values',
			'default_ttl' => 600,
		),
		'directory_markers'        => array(
			'label'       => 'Directory Map Markers',
			'default_ttl' => 120,
		),
		'directory_geocode'        => array(
			'label'       => 'Directory Place Lookups',
			'default_ttl' => 86400,
		),
		'directory_map_settings'   => array(
			'label'       => 'Directory Map Settings',
			'default_ttl' => 600,
		),
		'directory_export_reports' => array(
			'label'       => 'Directory Export Reports',
			'default_ttl' => 300,
		),
		'directory_listing_reviews' => array(
			'label'       => 'Listing Reviews',
			'default_ttl' => 120,
		),
		'events_list'              => array(
			'label'       => 'Events List',
			'default_ttl' => 120,
		),
		'events_single'            => array(
			'label'       => 'Single Event',
			'default_ttl' => 300,
		),
		'events_tickets'           => array(
			'label'       => 'Event Tickets',
			'default_ttl' => 300,
		),
		'events_attendee_fields'   => array(
			'label'       => 'Event Attendee Fields',
			'default_ttl' => 300,
		),
		'events_categories'        => array(
			'label'       => 'Event Categories',
			'default_ttl' => 600,
		),
		'events_venues'            => array(
			'label'       => 'Event Venues',
			'default_ttl' => 600,
		),
		'events_embed'             => array(
			'label'       => 'Events Embed Feed',
			'default_ttl' => 300,
		),
		'lms_courses'              => array(
			'label'       => 'LMS Courses',
			'default_ttl' => 300,
		),
		'lms_course_single'        => array(
			'label'       => 'Single Course',
			'default_ttl' => 300,
		),
		'lms_course_lessons'       => array(
			'label'       => 'Course Lessons',
			'default_ttl' => 300,
		),
		'lms_paths'                => array(
			'label'       => 'Learning Paths',
			'default_ttl' => 300,
		),
		'lms_path_single'          => array(
			'label'       => 'Single Learning Path',
			'default_ttl' => 300,
		),
		'lms_discovery'            => array(
			'label'       => 'LMS Discovery Blocks',
			'default_ttl' => 300,
		),
		'crm_tiers'                => array(
			'label'       => 'Membership Tiers',
			'default_ttl' => 3600,
		),
		'crm_tier_single'          => array(
			'label'       => 'Single Membership Tier',
			'default_ttl' => 3600,
		),
		'crm_me_entitlements'      => array(
			'label'       => 'Member Standing',
			'description' => 'The per-member standing cache used by Content Access. Agend webhooks clear it, so a lapse that arrives without a webhook applies within this time.',
			'default_ttl' => 300,
		),
		'crm_types'                => array(
			'label'       => 'CRM Deal Types',
			'default_ttl' => 3600,
		),
		'crm_stages'               => array(
			'label'       => 'CRM Pipeline Stages',
			'default_ttl' => 3600,
		),
		'cms_content'              => array(
			'label'       => 'CMS Content List',
			'default_ttl' => 300,
		),
		'cms_content_single'       => array(
			'label'       => 'Single CMS Content',
			'default_ttl' => 300,
		),
		// The Community surfaces. Loop sends nothing when a post is removed, so
		// these stay short; the Community settings also have a Clear button.
		'loop_channels'            => array(
			'label'       => 'Community Channels',
			'default_ttl' => 300,
		),
		'loop_public_announcements' => array(
			'label'       => 'Community Announcements',
			'default_ttl' => 120,
		),
		'loop_public_activity'     => array(
			'label'       => 'Community Posts',
			'default_ttl' => 120,
		),
		// Resources (Atlas). The collection list is only read for an editor's
		// picker and for the titles an editor has chosen; searches are stored
		// per query for visitors only, never for a signed-in member.
		'atlas_collections'        => array(
			'label'       => 'Resource Collections',
			'default_ttl' => 600,
		),
		'atlas_search'             => array(
			'label'       => 'Resource Search (Visitors)',
			'default_ttl' => 600,
		),
		'atlas_ask_budget'         => array(
			'label'       => 'Resource Ask Allowance',
			'default_ttl' => 60,
		),
		'jobs_list'                => array(
			'label'       => 'Jobs List',
			'default_ttl' => 300,
		),
		'jobs_single'              => array(
			'label'       => 'Single Job',
			'default_ttl' => 300,
		),
		// The board's category and tag filters; terms change rarely.
		'jobs_terms'               => array(
			'label'       => 'Job Categories and Tags',
			'default_ttl' => 900,
		),
		// Every catalogue page load fetches this, and brand and theme config rarely changes.
		'sites_config'             => array(
			'label'       => 'Site Config',
			'default_ttl' => 3600,
		),
	);

	/**
	 * Returns the full endpoint key map.
	 *
	 * @return array<string, array{label: string, default_ttl: int, description?: string}>
	 */
	public static function get_all_keys(): array {
		return self::$keys;
	}

	/**
	 * Clears all cached transients matching the given endpoint key prefix.
	 *
	 * Uses a `LIKE` query against the options table so that parameterised
	 * variants (e.g. search results with different query strings) are all
	 * removed in a single operation. Both the transient value and its
	 * corresponding timeout entry are deleted.
	 *
	 * @param string $endpoint_key Endpoint key from Agend_Apps_Cache::get_all_keys().
	 * @return bool True on success, false if no rows were affected or on failure.
	 */
	public static function clear( string $endpoint_key ): bool {
		global $wpdb;

		$value_pattern   = $wpdb->esc_like( '_transient_agend_apps_' . $endpoint_key ) . '%';
		$timeout_pattern = $wpdb->esc_like( '_transient_timeout_agend_apps_' . $endpoint_key ) . '%';

		$result = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$value_pattern,
				$timeout_pattern
			)
		);

		return false !== $result && $result > 0;
	}

	/**
	 * Clears all cached transients for every registered endpoint key.
	 */
	public static function clear_all(): void {
		foreach ( array_keys( self::$keys ) as $key ) {
			self::clear( $key );
		}
	}

	/**
	 * Builds a deterministic transient cache key for a given endpoint and parameter set.
	 *
	 * The returned string is suitable for use as the `$cache_key` argument to
	 * `Agend_Apps_API::get_cached()`. The full transient name stored by WordPress
	 * will be `agend_apps_{returned_key}`.
	 *
	 * @param string $endpoint_key Endpoint key, e.g. `directory_listings`.
	 * @param array  $params       Optional. Query parameters that affect the response. Default empty.
	 * @return string Cache key prefixed with the endpoint key.
	 */
	public static function build_key( string $endpoint_key, array $params = array() ): string {
		return $endpoint_key . '_' . md5( $endpoint_key . serialize( $params ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
	}

	/**
	 * Returns the count of currently stored Agend transients.
	 *
	 * Counts value entries only (excludes `_transient_timeout_` rows) to
	 * give an accurate picture of how many cached responses exist.
	 *
	 * @return int Number of stored Agend transients.
	 */
	public static function count_stored(): int {
		global $wpdb;

		$count = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name NOT LIKE %s",
				$wpdb->esc_like( '_transient_agend_apps_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_agend_apps_' ) . '%'
			)
		);

		return (int) $count;
	}
}
