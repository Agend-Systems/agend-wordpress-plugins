<?php
/**
 * REST routes for directory endpoints.
 *
 * @package Agend_Apps_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the directory REST routes.
 *
 * Called from `rest_api_init` via the main plugin bootstrap.
 */
function agend_apps_register_directory_routes(): void {
	$controller = new Agend_Apps_Directory_REST_Controller();
	$controller->register_routes();
}

/**
 * REST controller for directory endpoints.
 *
 * Read routes are publicly readable (no authentication required). Review
 * submission is a write and requires a valid WordPress nonce (`wp_rest`).
 * Listing create/update/delete and bulk upsert are intentionally NOT proxied:
 * they are administrative writes and are only available via the server-side
 * PHP functions in `includes/api/directory.php` and
 * `includes/api/directory-export-reports.php`.
 *
 * Exposes:
 * - `GET  /agend-apps/v1/directory/listings`                  — paginated listing index.
 * - `GET  /agend-apps/v1/directory/listings/{slugOrId}`       — single listing.
 * - `GET  /agend-apps/v1/directory/listings/{slugOrId}/reviews` — approved reviews for a listing.
 * - `GET  /agend-apps/v1/directory/categories`                — category list.
 * - `GET  /agend-apps/v1/directory/search`                    — search listings.
 * - `GET  /agend-apps/v1/directory/markers`                   — search results as map markers.
 * - `GET  /agend-apps/v1/directory/geocode`                   — resolve a place to a point.
 * - `GET  /agend-apps/v1/directory/map-settings`              — map defaults.
 * - `POST /agend-apps/v1/directory/reviews`                   — submit a listing review.
 */
class Agend_Apps_Directory_REST_Controller extends Agend_Apps_REST_Controller {

	/**
	 * Resource base for directory routes.
	 *
	 * @var string
	 */
	protected $rest_base = 'directory';

	/**
	 * Registers the REST routes for this controller.
	 */
	public function register_routes(): void {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/listings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_listings' ),
					'permission_callback' => '__return_true',
					'args'                => $this->listings_args(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/listings/(?P<listing_id>[a-zA-Z0-9_-]+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_listing' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'listing_id' => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'include'    => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/listings/(?P<listing_id>[a-zA-Z0-9_-]+)/reviews',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_listing_reviews' ),
					'permission_callback' => '__return_true',
					'args'                => $this->reviews_args(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/categories',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_categories' ),
					'permission_callback' => '__return_true',
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/facets',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_facets' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'fields' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/export-reports',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_export_reports' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						// Set by the widget just before a download, so the
						// parameters it applies come from the report's
						// current declaration rather than a listing an
						// author edited since the transient was cached.
						'fresh' => array(
							'type'              => 'boolean',
							'sanitize_callback' => 'rest_sanitize_boolean',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/export-reports/(?P<report_id>[a-zA-Z0-9_-]+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'run_export_report' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'format' => array(
							'type'              => 'string',
							'enum'              => array( 'csv', 'xlsx' ),
							'default'           => 'csv',
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/search',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'search' ),
					'permission_callback' => '__return_true',
					'args'                => $this->search_args(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/markers',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_markers' ),
					'permission_callback' => '__return_true',
					'args'                => $this->markers_args(),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/geocode',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'geocode' ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'q' => array(
							'required'          => true,
							'type'              => 'string',
							'minLength'         => 1,
							'maxLength'         => 200,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/map-settings',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_map_settings' ),
					'permission_callback' => '__return_true',
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/reviews',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'submit_review' ),
					'permission_callback' => array( $this, 'nonce_check' ),
					'args'                => array(
						'listing_id'     => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'rating'         => array(
							'required'          => true,
							'type'              => 'integer',
							'minimum'           => 1,
							'maximum'           => 5,
							'sanitize_callback' => 'absint',
						),
						// Optional at the proxy layer: a signed-in member's
						// reviewer identity is derived server-side from the
						// bearer (SPEC-CORE-20260722 US-2.2/US-2.6). The
						// gateway still rejects guest submissions without them.
						'reviewer_name'  => array(
							'required'          => false,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
						),
						'reviewer_email' => array(
							'required'          => false,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_email',
						),
						'content'        => array(
							'required'          => true,
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_textarea_field',
						),
					),
				),
			)
		);

		// Member self-service: the signed-in member's own listing
		// (SPEC-CORE-20260722 US-2.6). Identity is derived server-side from
		// the member bearer; no listing id is accepted from the browser.
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/me/listing',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_my_listing' ),
					'permission_callback' => array( $this, 'nonce_check' ),
				),
				array(
					'methods'             => 'PATCH',
					'callback'            => array( $this, 'update_my_listing' ),
					'permission_callback' => array( $this, 'nonce_check' ),
				),
			)
		);
	}

	/**
	 * Validates the WordPress REST nonce for the current request.
	 *
	 * @param WP_REST_Request $request Current request.
	 *
	 * @return bool True if the nonce is valid, false otherwise.
	 */
	public function nonce_check( WP_REST_Request $request ): bool {
		$nonce = $request->get_header( 'X-WP-Nonce' );

		return false !== wp_verify_nonce( $nonce, 'wp_rest' );
	}

	/**
	 * Returns a paginated list of directory listings.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_listings( WP_REST_Request $request ): WP_REST_Response {
		$allowed = array( 'page', 'per_page', 'category' );
		$query   = array_filter(
			$request->get_params(),
			function ( $key ) use ( $allowed ) {
				return in_array( $key, $allowed, true );
			},
			ARRAY_FILTER_USE_KEY
		);

		$result = agend_apps_directory_get_listings( $query );
		return $this->prepare_api_response( $result );
	}

	/**
	 * Returns a single directory listing.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_listing( WP_REST_Request $request ): WP_REST_Response {
		$listing_id = $request->get_param( 'listing_id' );

		$query   = array();
		$include = (string) $request->get_param( 'include' );
		if ( '' !== $include ) {
			$query['include'] = $include;
		}

		$result = agend_apps_directory_get_listing( $listing_id, $query );
		return $this->prepare_api_response( $result );
	}

	/**
	 * Returns all directory categories.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_categories( WP_REST_Request $request ): WP_REST_Response {
		$result = agend_apps_directory_get_categories();
		return $this->prepare_api_response( $result );
	}

	/**
	 * Returns the signed-in member's own listing (or null).
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_my_listing( WP_REST_Request $request ): WP_REST_Response {
		if ( 0 === get_current_user_id() ) {
			return new WP_REST_Response( array( 'data' => null ), 200 );
		}

		$result = agend_apps_directory_get_my_listing();
		return $this->prepare_api_response( $result );
	}

	/**
	 * Updates the signed-in member's own listing.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function update_my_listing( WP_REST_Request $request ): WP_REST_Response {
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			$body = array();
		}

		$result = agend_apps_directory_update_my_listing( $body );
		return $this->prepare_api_response( $result );
	}

	/**
	 * The query arguments `GET /directory/search` accepts, shared with
	 * `GET /directory/markers` so a map asks exactly the question its
	 * catalogue asked.
	 *
	 * @return array
	 */
	private function search_args(): array {
		return array(
			'q'                 => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'search'            => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'page'              => self::bounded_integer_arg( 1 ),
			'limit'             => self::bounded_integer_arg( 1, 100 ),
			'per_page'          => self::bounded_integer_arg( 1, 100 ),
			'category'          => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'rating'            => array(
				'type'              => 'number',
				'minimum'           => 1,
				'maximum'           => 5,
				'sanitize_callback' => 'rest_sanitize_request_arg',
			),
			'featured'          => array(
				'type'              => 'boolean',
				'sanitize_callback' => 'rest_sanitize_boolean',
			),
			'sortBy'            => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'sortOrder'         => array(
				'type'              => 'string',
				'enum'              => array( 'asc', 'desc' ),
				'sanitize_callback' => 'sanitize_text_field',
			),
			'excludeCategories' => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			// Comma-separated ids, forwarded verbatim: the gateway
			// search decoder splits them itself.
			'tag_ids'           => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'badge_ids'         => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			// Comma-separated location values; the gateway splits them
			// itself and rejects a bracket-encoded array with a 422.
			'city'              => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'state'             => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'postcode'          => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'country'           => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			// One free-text value matched against the names of a listing's
			// locations. Never comma-split, so it is forwarded as typed.
			'locationName'      => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'sponsor_level'     => array(
				'type'              => 'integer',
				'minimum'           => 0,
				'maximum'           => 3,
				'sanitize_callback' => 'absint',
			),
			// Proximity search: the gateway applies it only when all
			// three arrive together. Sanitised by WordPress's own schema
			// sanitiser (a float for `number`): PHP's built-in floatval()
			// rejects the three arguments WordPress passes a sanitise
			// callback, so it fatalled every request carrying one of these.
			'lat'               => array(
				'type'              => 'number',
				'minimum'           => -90,
				'maximum'           => 90,
				'sanitize_callback' => 'rest_sanitize_request_arg',
			),
			'lng'               => array(
				'type'              => 'number',
				'minimum'           => -180,
				'maximum'           => 180,
				'sanitize_callback' => 'rest_sanitize_request_arg',
			),
			'radius'            => array(
				'type'              => 'number',
				'minimum'           => 1,
				'maximum'           => 1000,
				'sanitize_callback' => 'rest_sanitize_request_arg',
			),
			// A map viewport, north,south,east,west in degrees. The gateway rejects
			// it alongside lat/lng/radius, so a caller sends one or the other.
			'bbox'              => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
		);
	}

	/**
	 * The query arguments `GET /directory/markers` accepts: every search
	 * argument, with a page size up to the gateway's 2000 marker cap, plus
	 * `projection` (`points` for id, name and coordinates only, `markers`
	 * for the full map marker) and `ids` (up to 100 comma-separated listing
	 * ids). A value of either outside that is dropped rather than forwarded,
	 * so the gateway only ever sees one the map itself would send.
	 *
	 * @return array
	 */
	private function markers_args(): array {
		$args = $this->search_args();
		unset( $args['page'], $args['per_page'], $args['sortBy'], $args['sortOrder'] );
		$args['limit']      = self::bounded_integer_arg( 1, 2000 );
		$args['projection'] = array(
			'type'              => 'string',
			'sanitize_callback' => static function ( $value ): string {
				return is_string( $value ) && in_array( $value, array( 'points', 'markers' ), true ) ? $value : '';
			},
		);
		$args['ids']        = array(
			'type'              => 'string',
			'sanitize_callback' => static function ( $value ): string {
				if ( ! is_string( $value ) || '' === $value ) {
					return '';
				}
				$ids = explode( ',', $value );
				if ( count( $ids ) > 100 ) {
					return '';
				}
				foreach ( $ids as $id ) {
					if ( 1 !== preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $id ) ) {
						return '';
					}
				}
				return $value;
			},
		);
		return $args;
	}

	/**
	 * The query arguments `GET /directory/listings` accepts.
	 *
	 * @return array
	 */
	private function listings_args(): array {
		return array(
			'page'     => self::bounded_integer_arg( 1 ),
			'per_page' => self::bounded_integer_arg( 1, 100 ),
			'category' => array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
		);
	}

	/**
	 * The arguments `GET /directory/listings/{slugOrId}/reviews` accepts.
	 *
	 * @return array
	 */
	private function reviews_args(): array {
		return array(
			'listing_id' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'page'       => self::bounded_integer_arg( 1 ),
			'limit'      => self::bounded_integer_arg( 1, 100 ),
		);
	}

	/**
	 * An integer argument whose declared bounds are enforced.
	 *
	 * WordPress checks `minimum` and `maximum` only for an argument with no
	 * sanitize callback of its own, so the callback applies them itself. A
	 * value outside the range is moved to the nearest bound rather than
	 * refused, so a request asking for a larger page still gets a page.
	 *
	 * @param int      $minimum Smallest accepted value.
	 * @param int|null $maximum Largest accepted value, or null for no upper bound.
	 * @return array
	 */
	private static function bounded_integer_arg( int $minimum, ?int $maximum = null ): array {
		$arg = array(
			'type'              => 'integer',
			'minimum'           => $minimum,
			'sanitize_callback' => static function ( $value ) use ( $minimum, $maximum ): int {
				$value = max( $minimum, (int) $value );
				return null === $maximum ? $value : min( $maximum, $value );
			},
		);
		if ( null !== $maximum ) {
			$arg['maximum'] = $maximum;
		}
		return $arg;
	}

	/**
	 * Searches directory listings.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function search( WP_REST_Request $request ): WP_REST_Response {
		$search_query = (string) ( $request->get_param( 'q' ) ?? $request->get_param( 'search' ) ?? '' );

		$result = agend_apps_directory_search( $search_query, $this->search_filters( $request ) );
		return $this->prepare_api_response( $result );
	}

	/**
	 * The catalogue filters a search or markers request forwards to the
	 * gateway, with `category` translated to the canonical `category_ids`.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return array
	 */
	private function search_filters( WP_REST_Request $request ): array {
		// Forward the widget's catalogue filters to the gateway search. `rating`,
		// `featured`, `sortBy`, `sortOrder`, and `excludeCategories` are accepted
		// verbatim by the gateway GET decoder; `category` is translated to the
		// canonical `category_ids`.
		$filter_keys = array(
			'page',
			'limit',
			'per_page',
			'category',
			'tag_ids',
			'badge_ids',
			'city',
			'state',
			'postcode',
			'country',
			'locationName',
			'sponsor_level',
			'lat',
			'lng',
			'radius',
			'rating',
			'featured',
			'sortBy',
			'sortOrder',
			'excludeCategories',
			// Bracket notation arrives already parsed into a nested array by
			// PHP, and add_query_arg() re-encodes it the same way for the
			// gateway: custom_fields[key]=a,b and custom_fields[key][min]=5.
			'custom_fields',
			'bbox',
		);
		$filters     = array_filter(
			$request->get_params(),
			function ( $key ) use ( $filter_keys ) {
				return in_array( $key, $filter_keys, true );
			},
			ARRAY_FILTER_USE_KEY
		);

		// The gateway filters search results by `category_ids` (canonical),
		// not the legacy single `category` param. Translate it here so the
		// public REST contract stays stable while the upstream call is current.
		if ( isset( $filters['category'] ) ) {
			$filters['category_ids'] = $filters['category'];
			unset( $filters['category'] );
		}

		return $filters;
	}

	/**
	 * Returns the listings matching a search as map markers.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_markers( WP_REST_Request $request ): WP_REST_Response {
		$search_query = (string) ( $request->get_param( 'q' ) ?? $request->get_param( 'search' ) ?? '' );

		$filters = $this->search_filters( $request );
		// Paging and ordering mean nothing to a set of pins.
		unset( $filters['page'], $filters['per_page'], $filters['sortBy'], $filters['sortOrder'] );

		foreach ( array( 'projection', 'ids' ) as $key ) {
			$value = $request->get_param( $key );
			if ( is_string( $value ) && '' !== $value ) {
				$filters[ $key ] = $value;
			}
		}

		return $this->prepare_api_response( agend_apps_directory_get_markers( $search_query, $filters ) );
	}

	/**
	 * Resolves an address, suburb or postcode to a point.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function geocode( WP_REST_Request $request ): WP_REST_Response {
		return $this->prepare_api_response( agend_apps_directory_geocode( (string) $request->get_param( 'q' ) ) );
	}

	/**
	 * Returns the directory's map defaults.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_map_settings( WP_REST_Request $request ): WP_REST_Response { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- REST callback signature.
		return $this->prepare_api_response( agend_apps_directory_get_map_settings() );
	}

	/**
	 * Returns the export reports the current visitor may run.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_export_reports( WP_REST_Request $request ): WP_REST_Response {
		$fresh = rest_sanitize_boolean( $request->get_param( 'fresh' ) );
		return $this->prepare_api_response( agend_apps_directory_get_export_reports( $fresh ) );
	}

	/**
	 * Runs an export report and streams the file back to the browser.
	 *
	 * The gateway returns the file's bytes, so this echoes them with their own
	 * content headers rather than wrapping them in a JSON envelope. The
	 * browser never talks to the gateway directly: the API key and the
	 * member's bearer stay server-side, and the visitor's own reachable report
	 * set is what decides whether this returns anything at all.
	 *
	 * Every parameter except the reserved ones is forwarded as a report
	 * parameter; the gateway rejects a name the report does not declare.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response (errors only; success exits after streaming).
	 */
	public function run_export_report( WP_REST_Request $request ) {
		$report_id = (string) $request->get_param( 'report_id' );
		$format    = (string) ( $request->get_param( 'format' ) ?? 'csv' );

		$reserved   = array( 'report_id', 'format', '_wpnonce', '_locale', 'rest_route' );
		$parameters = array();
		foreach ( $request->get_params() as $name => $value ) {
			if ( in_array( $name, $reserved, true ) || is_array( $value ) ) {
				continue;
			}
			$parameters[ $name ] = sanitize_text_field( (string) $value );
		}

		$result = agend_apps_directory_run_export_report( $report_id, $parameters, $format );

		if ( is_wp_error( $result ) ) {
			$forwarded = agend_apps_directory_export_report_error_envelope( $result );

			// Forwarded verbatim when the gateway explained itself, so the
			// visitor reads why rather than a generic failure. Anything else,
			// including a gateway that predates the explanation, falls through
			// to the ordinary error translation.
			if ( null !== $forwarded ) {
				return new WP_REST_Response( $forwarded['body'], $forwarded['status'] );
			}

			return $this->prepare_api_response( $result );
		}

		$content_type = ! empty( $result['content_type'] )
			? (string) $result['content_type']
			: 'text/csv; charset=utf-8';
		$disposition  = ! empty( $result['content_disposition'] )
			? (string) $result['content_disposition']
			: 'attachment; filename="' . sanitize_file_name( $report_id ) . '.' . ( 'xlsx' === $format ? 'xlsx' : 'csv' ) . '"';

		header( 'Content-Type: ' . $content_type );
		header( 'Content-Disposition: ' . $disposition );
		// An export reflects the caller's own entitlements, so it must never
		// be held by a shared cache.
		header( 'Cache-Control: private, no-store' );
		echo (string) $result['body']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Raw file passthrough; not HTML.
		exit;
	}

	/**
	 * Returns the directory's filterable facets and their values.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_facets( WP_REST_Request $request ): WP_REST_Response {
		$fields = (string) ( $request->get_param( 'fields' ) ?? '' );
		$result = agend_apps_directory_get_facets(
			'' === $fields ? array() : explode( ',', $fields )
		);
		return $this->prepare_api_response( $result );
	}

	/**
	 * Returns the approved reviews for a single directory listing.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function get_listing_reviews( WP_REST_Request $request ): WP_REST_Response {
		$listing_id = $request->get_param( 'listing_id' );

		$query_keys = array( 'page', 'limit' );
		$query      = array_filter(
			$request->get_params(),
			function ( $key ) use ( $query_keys ) {
				return in_array( $key, $query_keys, true );
			},
			ARRAY_FILTER_USE_KEY
		);

		$result = agend_apps_directory_get_listing_reviews( $listing_id, $query );
		return $this->prepare_api_response( $result );
	}

	/**
	 * Submits a review for a directory listing.
	 *
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response REST response.
	 */
	public function submit_review( WP_REST_Request $request ): WP_REST_Response {
		$review = array(
			'listing_id'     => $request->get_param( 'listing_id' ),
			'rating'         => (int) $request->get_param( 'rating' ),
			'reviewer_name'  => $request->get_param( 'reviewer_name' ),
			'reviewer_email' => $request->get_param( 'reviewer_email' ),
			'content'        => $request->get_param( 'content' ),
		);

		$result = agend_apps_directory_submit_review( $review );
		return $this->prepare_api_response( $result );
	}
}
