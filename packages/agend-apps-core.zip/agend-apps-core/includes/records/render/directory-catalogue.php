<?php
/**
 * Server render of the directory catalogue surface.
 *
 * Page-builder agnostic: the same markup and client config whichever editor
 * placed the surface. An adapter passes the surface's settings (see
 * `agend_apps_records_surface_schema()`) and echoes the returned HTML.
 *
 * @package Agend_Apps_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Every renderer asks the surface gate before it fetches or draws anything;
// callers that load one renderer on its own (the unit tests) need it present.
require_once __DIR__ . '/../surface-gate.php';

// The sizing settings are sanitised against the schema's own option lists, so
// the two cannot drift; a caller loading this renderer alone needs them too.
require_once __DIR__ . '/../schema/directory-catalogue.php';

// The Detail View's item list options are read through the shared item list
// helpers, which live with the formatters.
require_once __DIR__ . '/../format.php';

/**
 * Normalises a SELECT2 multiple value to a clean string list.
 *
 * @param mixed $value Raw setting value.
 * @return array List of non-empty strings.
 */
function agend_apps_records_directory_catalogue_string_list( $value ): array {
	if ( ! is_array( $value ) ) {
		return array();
	}

	return array_values( array_filter( array_map( 'strval', $value ), 'strlen' ) );
}

/**
 * A choice-list setting's value, or '' when it is not one of the list's
 * non-empty choices.
 *
 * @param mixed $value   Raw setting value.
 * @param array $options The schema's choices, keyed by value.
 * @return string
 */
function agend_apps_records_directory_catalogue_choice( $value, array $options ): string {
	$value = is_scalar( $value ) ? (string) $value : '';

	return ( '' !== $value && array_key_exists( $value, $options ) ) ? $value : '';
}

/**
 * The width of a side filter column as a share of the catalogue, or '' for
 * the stylesheet's own width.
 *
 * Only a catalogue with a filter template placed down the left or right has a
 * column to size. The editor hides the setting otherwise, so a value left over
 * from a layout the author has since changed is ignored rather than carried
 * into the markup.
 *
 * @param array $s Surface settings.
 * @return string A CSS percentage such as '33%', or ''.
 */
function agend_apps_records_directory_catalogue_filter_column( array $s ): string {
	if ( (int) ( $s['filter_template'] ?? 0 ) < 1 || ! in_array( $s['filter_position'] ?? 'top', array( 'left', 'right' ), true ) ) {
		return '';
	}

	return agend_apps_records_directory_catalogue_choice( $s['filter_column_width'] ?? '', agend_apps_records_directory_catalogue_filter_column_options() );
}

/**
 * Whether this catalogue's listing details are behind a sign-in for the
 * visitor being served: the "Require sign-in to view details" setting is on
 * and nobody is signed in.
 *
 * Visitor-specific by design, so a signed-in visitor gets exactly the markup
 * and config they got before the setting existed.
 *
 * @param array $s Surface settings.
 * @return bool
 */
function agend_apps_records_directory_catalogue_login_gate( array $s ): bool {
	return 'yes' === ( $s['require_login_for_detail'] ?? '' ) && ! is_user_logged_in();
}

/**
 * Builds the client-side config object from the widget settings.
 *
 * @param array $s Surface settings (Elementor-shaped values: toggles are 'yes'/'').
 * @return array Config passed to the frontend script as JSON.
 */
function agend_apps_records_directory_catalogue_build_config( array $s ): array {
	$colours = agend_apps_records_resolve_colours(
		array( 'inherit_colours' => (string) ( $s['inherit_colours'] ?? 'yes' ) ) + $s,
		AGEND_APPS_RECORDS_COLOUR_DEFAULTS
	);

	$config = array(
		'heading'    => array(
			'show'     => 'yes' === ( $s['show_heading'] ?? 'yes' ),
			'title'    => (string) ( $s['heading_text'] ?? '' ),
			'subtitle' => (string) ( $s['subheading_text'] ?? '' ),
		),
		'layout'     => array(
			'style'      => (string) ( $s['layout_style'] ?? 'grid' ),
			'desktop'    => (int) ( $s['columns_desktop'] ?? 3 ),
			'tablet'     => (int) ( $s['columns_tablet'] ?? 2 ),
			'mobile'     => (int) ( $s['columns_mobile'] ?? 1 ),
			'cardRadius' => (int) ( $s['card_radius'] ?? 10 ),
		),
		'card'       => array(
			'logo'          => 'yes' === ( $s['show_logo'] ?? 'yes' ),
			'rating'        => 'yes' === ( $s['show_rating'] ?? 'yes' ),
			'category'      => 'yes' === ( $s['show_category'] ?? 'yes' ),
			'location'      => 'yes' === ( $s['show_location'] ?? 'yes' ),
			'badges'        => 'yes' === ( $s['show_badges'] ?? 'yes' ),
			'description'   => 'yes' === ( $s['show_description'] ?? 'yes' ),
			'excerptLength' => (int) ( $s['excerpt_length'] ?? 110 ),
		),
		'filters'    => array(
			'search'        => 'yes' === ( $s['show_search'] ?? 'yes' ),
			'category'      => 'yes' === ( $s['show_category_filter'] ?? 'yes' ),
			'rating'        => 'yes' === ( $s['show_rating_filter'] ?? 'yes' ),
			'categoryMulti' => 'yes' === ( $s['multi_category_filter'] ?? 'no' ),
		),
		'exclusions' => array(
			'categories' => agend_apps_records_directory_catalogue_string_list( $s['exclude_categories'] ?? array() ),
			'featured'   => 'yes' === ( $s['featured_only'] ?? 'no' ),
		),
		'detail'     => array(
			'reviews'    => 'yes' === ( $s['show_reviews'] ?? 'yes' ),
			// Also gated on the review-form optional feature: a key without
			// the directory.reviews.manage scope never gets the submission
			// form, whatever this widget instance's own toggle says
			// (SPEC-CORE-20260908 scope-gated features).
			'reviewForm' => 'yes' === ( $s['show_review_form'] ?? 'yes' )
				&& ( ! function_exists( 'agend_apps_records_feature_available' ) || agend_apps_records_feature_available( 'directory_review_form' ) ),
		),
		'pagination' => array(
			'style'   => (string) ( $s['pagination_style'] ?? 'numbered' ),
			'perPage' => (int) ( $s['per_page'] ?? 12 ),
		),
		'colours'    => $colours['colours'],
		'theme'      => array(
			'inheritFonts' => 'yes' === ( $s['inherit_fonts'] ?? 'yes' ),
			'colourSource' => $colours['source'],
		),
	);

	// Both sizing settings write a key only when set, like the two below, so a
	// catalogue that leaves them alone keeps its existing config (and its
	// pinned render fixtures) byte for byte.
	$filter_column = agend_apps_records_directory_catalogue_filter_column( $s );
	if ( '' !== $filter_column ) {
		$config['layout']['filterColumn'] = $filter_column;
	}

	$results_height = agend_apps_records_directory_catalogue_choice( $s['results_max_height'] ?? '', agend_apps_records_directory_catalogue_results_height_options() );
	if ( '' !== $results_height ) {
		$config['layout']['resultsMaxHeight'] = $results_height;
	}

	// Distance shows by default, so only turning it off writes a key: every
	// catalogue that leaves it on keeps its existing config (and its pinned
	// render fixtures) byte for byte.
	if ( 'yes' !== ( $s['show_distance'] ?? 'yes' ) ) {
		$config['card']['distance'] = false;
	}

	// Written only when it differs from the defaults (a table of every item
	// field), like the two above, so a catalogue that leaves item lists alone
	// keeps its existing config (and its pinned render fixtures) unchanged.
	$item_list = agend_apps_records_item_list_options( $s );
	if ( 'table' !== $item_list['layout'] || ! empty( $item_list['fields'] ) ) {
		$config['detail']['itemList'] = $item_list;
	}

	// Written only for a visitor the sign-in requirement applies to, so every
	// other catalogue keeps its existing config (and its pinned render
	// fixtures) unchanged. The script sends that visitor to the sign-in page
	// instead of opening a listing, and builds its own links the same way
	// agend_apps_records_render_cards() does.
	if ( agend_apps_records_directory_catalogue_login_gate( $s ) ) {
		$config['requireLogin'] = true;
		$config['loginUrl']     = wp_login_url();
	}

	// Written only when switched on, so a catalogue without it keeps its
	// existing config (and its pinned render fixtures) unchanged.
	if ( 'yes' === ( $s['show_result_count'] ?? '' ) ) {
		$text = trim( (string) ( $s['result_count_text'] ?? '' ) );

		$config['resultCount'] = array(
			/* translators: {from}, {to} and {total} are replaced with numbers. */
			'text' => '' !== $text ? $text : __( 'Showing {from}–{to} of {total}', 'agend-apps-core' ),
		);
	}

	return $config;
}

/**
 * Whether a listing opens on its own server-rendered page rather than in
 * place: the "Server-rendered detail pages" setting, or a listing detail
 * template, which ssr-detail.php always renders server-side whatever that
 * setting says. Without the second, a card on the dedicated page drew the
 * built-in detail in place and the template only showed on a direct visit.
 *
 * @return bool
 */
function agend_apps_records_directory_catalogue_ssr_detail(): bool {
	if ( function_exists( 'agend_apps_records_ssr_detail_enabled' ) && agend_apps_records_ssr_detail_enabled() ) {
		return true;
	}
	return class_exists( 'Agend_Apps_Records_Pages' ) && Agend_Apps_Records_Pages::detail_template_id( 'listing' ) > 0;
}

/**
 * The result count line for one page of results, or '' when there is
 * nothing to count.
 *
 * Mirrors formatCount() in assets/js/directory-catalogue.js, which updates
 * the same line after every filter change.
 *
 * The page size is the one the catalogue requested. A `limit` in the
 * pagination meta wins when present, since it is what the gateway actually
 * applied; nothing else in the pager reads it, so it is never relied on.
 *
 * @param string     $text       The author's text, with {from}, {to} and {total} tokens.
 * @param array|null $pagination The list's pagination meta (page, total, and possibly limit).
 * @param int        $per_page   The page size the catalogue requested.
 * @return string
 */
function agend_apps_records_directory_catalogue_count_text( string $text, ?array $pagination, int $per_page ): string {
	$total = (int) ( $pagination['total'] ?? 0 );
	if ( $total < 1 ) {
		return '';
	}

	$page  = max( 1, (int) ( $pagination['page'] ?? 1 ) );
	$limit = max( 1, (int) ( $pagination['limit'] ?? $per_page ) );
	$from  = min( $total, ( $page - 1 ) * $limit + 1 );
	$to    = min( $total, $page * $limit );

	return strtr(
		$text,
		array(
			'{from}'  => number_format_i18n( $from ),
			'{to}'    => number_format_i18n( $to ),
			'{total}' => number_format_i18n( $total ),
		)
	);
}

/**
 * Renders the surface container on the front end, returned as HTML.
 *
 * The catalogue itself is rendered client-side from the config below by
 * assets/js/directory-catalogue.js.
 */
function agend_apps_records_render_directory_catalogue( array $settings ): string {
	$gate = agend_apps_records_surface_gate( 'directory-catalogue', false );
	if ( null !== $gate ) {
		return $gate;
	}

	ob_start();
	// A catalogue inside a card template would fetch the list once per
	// card; nothing sensible can come of it.
	if ( Agend_Apps_Records_Record_Context::has() ) {
		return (string) ob_get_clean();
	}

	$config   = agend_apps_records_directory_catalogue_build_config( $settings );

	// US-3.2: path-based detail routing. The directory detail rule
	// (registered in routing.php) exposes the slug on
	// the current page URL as /{page}/listing/{slug}/ via the private
	// `agend_dir_listing` query var (the public `listing` segment maps to it;
	// the namespaced var avoids the common `listing` query-var collision).
	// The slug is injected server-side so a direct load renders the detail
	// with no catalogue flash; the base page path lets the script build
	// pretty links, and it falls back to the ?agend_listing= query param when
	// pretty permalinks are off or the base path is unavailable.
	$page_id               = get_queried_object_id();
	$base_path             = $page_id ? get_permalink( $page_id ) : '';
	$config['deepLink']    = sanitize_title( (string) get_query_var( 'agend_dir_listing' ) );
	$config['prettyLinks'] = (bool) get_option( 'permalink_structure' );
	$config['basePath']    = is_string( $base_path ) ? $base_path : '';
	// When server-rendered detail pages are on, cards navigate to the
	// server-rendered detail URL (a real child page) instead of swapping the
	// detail in client-side, so breadcrumbs and SEO resolve natively.
	$config['ssrDetail']   = agend_apps_records_directory_catalogue_ssr_detail();
	// Member LMS achievements ("Badges & Credentials") are opt-in and require
	// the directory.achievements.browse scope on the account's API key.
	$config['showAchievements'] = function_exists( 'agend_apps_records_show_achievements_enabled' )
		&& agend_apps_records_show_achievements_enabled();

	// Dedicated Directory page: with one configured, a catalogue elsewhere
	// never opens a detail in place, and deepLink is only honoured on that
	// page (unchanged behaviour when no page is set).
	$config['detailBase']   = Agend_Apps_Records_Pages::page_url( 'listing' );
	$config['onDetailPage'] = '' === $config['detailBase']
		|| Agend_Apps_Records_Pages::is_dedicated_page( 'listing', $page_id );
	if ( ! $config['onDetailPage'] ) {
		$config['deepLink'] = '';
	}

	$style   = agend_apps_records_directory_catalogue_inline_style( $config );
	$columns = ( 'list' === $config['layout']['style'] ) ? 1 : max( 1, (int) $config['layout']['desktop'] );

	// Card template mode: the first page is rendered here through the
	// template and later pages arrive as fragments from
	// /agend-apps/v1/cards/listings.
	$template_id = (int) ( $settings['card_template'] ?? 0 );
	if ( $template_id > 0 && Agend_Apps_Templates::is_valid_template( $template_id ) ) {
		$config['cardMode']      = 'template';
		$config['filterTemplate'] = agend_apps_records_directory_catalogue_filter_template_id( $settings );
		$config['filterPosition'] = (string) ( $settings['filter_position'] ?? 'top' );
		$config['cardTemplate']  = $template_id;
		$config['cardLinkWhole'] = 'yes' === ( $settings['card_link_whole'] ?? 'yes' );
		$config['hostPageId']    = (int) $page_id;
		$config['restBase']      = esc_url_raw( rest_url( 'agend-apps/v1' ) );
		$config['fragmentPath']  = '/cards/listings';
		agend_apps_records_directory_catalogue_render_templated( $config, $template_id, $style, $columns );
		return (string) ob_get_clean();
	}
	$config['cardMode'] = 'legacy';
	$config['filterTemplate'] = agend_apps_records_directory_catalogue_filter_template_id( $settings );
	$config['filterPosition'] = (string) ( $settings['filter_position'] ?? 'top' );

	// One complete grid row of skeleton placeholders as the initial state
	// (3 when the layout is a single column or list), so no plain "Loading…"
	// text flashes before the script takes over.
	$skeletons = ( 1 === $columns ) ? 3 : $columns;
	?>
		<div class="agend-directory-catalogue<?php echo esc_attr( agend_apps_records_directory_catalogue_scroll_class( $config ) ); ?>" style="<?php echo esc_attr( $style ); ?>" data-agend-directory-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
			<span class="agend-visually-hidden" role="status"><?php esc_html_e( 'Loading listings…', 'agend-apps-core' ); ?></span>
			<div class="agend-dir-filter-slot"><?php echo agend_apps_records_directory_catalogue_render_filters( (int) $config['filterTemplate'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Template output. ?></div>
			<div class="agend-dir-grid agend-dir-grid--<?php echo esc_attr( $config['layout']['style'] ); ?>" style="--agend-dir-cols-desktop:<?php echo (int) $columns; ?>;">
				<?php for ( $i = 0; $i < $skeletons; $i++ ) : ?>
					<article class="agend-dir-card agend-dir-skeleton" aria-hidden="true">
						<div class="agend-dir-card__media"></div>
						<div class="agend-dir-card__body">
							<div class="agend-skel-line" style="width:40%"></div>
							<div class="agend-skel-line" style="width:85%"></div>
							<div class="agend-skel-line" style="width:60%"></div>
						</div>
					</article>
				<?php endfor; ?>
			</div>
		</div>
		<?php
	return (string) ob_get_clean();
}

/**
 * The configured filter template id, or 0.
 *
 * @param array $settings Widget settings.
 * @return int
 */
function agend_apps_records_directory_catalogue_filter_template_id( array $settings ): int {
	$id = (int) ( $settings['filter_template'] ?? 0 );
	return ( $id > 0 && Agend_Apps_Templates::is_valid_template( $id ) ) ? $id : 0;
}

/**
 * Renders the filter template, with the record type in scope so the filter
 * widgets inside know which catalogue they drive.
 *
 * @param int $template_id The filter template id.
 * @return string
 */
function agend_apps_records_directory_catalogue_render_filters( int $template_id ): string {
	if ( 0 === $template_id ) {
		return '';
	}
	Agend_Apps_Records_Filter_Context::set( 'listing' );
	try {
		return Agend_Apps_Templates::render_plain( $template_id );
	} finally {
		Agend_Apps_Records_Filter_Context::reset();
	}
}

/**
 * The colour and radius CSS variables the catalogue styles read.
 *
 * @param array $config The widget config.
 * @return string
 */
function agend_apps_records_directory_catalogue_inline_style( array $config ): string {
	$style = sprintf(
		'--agend-dir-heading:%1$s;--agend-dir-body:%2$s;--agend-dir-accent:%3$s;--agend-dir-button:%4$s;--agend-dir-button-text:%5$s;--agend-dir-card-radius:%6$dpx;',
		esc_attr( $config['colours']['heading'] ),
		esc_attr( $config['colours']['body'] ),
		esc_attr( $config['colours']['accent'] ),
		esc_attr( $config['colours']['button'] ),
		esc_attr( $config['colours']['buttonText'] ),
		(int) $config['layout']['cardRadius']
	);

	// Set on the root, so the grid the filters sit in and the results list pick
	// them up wherever the script has since moved them.
	if ( ! empty( $config['layout']['filterColumn'] ) ) {
		$style .= '--agend-filter-column:' . esc_attr( $config['layout']['filterColumn'] ) . ';';
	}
	if ( ! empty( $config['layout']['resultsMaxHeight'] ) ) {
		$style .= '--agend-dir-results-max-height:' . esc_attr( $config['layout']['resultsMaxHeight'] ) . ';';
	}

	return $style;
}

/**
 * The root's modifier class when the results list has a height cap, with its
 * leading space, or '' for none. The stylesheet makes the list scroll only
 * under this class, so an uncapped catalogue never clips its card shadows.
 *
 * @param array $config The widget config.
 * @return string
 */
function agend_apps_records_directory_catalogue_scroll_class( array $config ): string {
	return empty( $config['layout']['resultsMaxHeight'] ) ? '' : ' agend-directory-catalogue--scroll-results';
}

/**
 * Renders the first page of cards through the card template.
 *
 * The filter bar and pagination stay script-built, so the markup leaves a
 * slot for each; the script adopts this DOM instead of rebuilding it.
 *
 * @param array  $config      The widget config (with card template keys).
 * @param int    $template_id The card template id.
 * @param string $style       Inline CSS variables.
 * @param int    $columns     Desktop column count.
 */
function agend_apps_records_directory_catalogue_render_templated( array $config, int $template_id, string $style, int $columns ): void {
	$query = agend_apps_records_with_search_include( agend_apps_records_listings_list_args( $config, 1 ), $template_id );
	$list  = agend_apps_records_unwrap_list( agend_apps_records_fetch_list( 'listing', $query ) );
	$cards = agend_apps_records_render_cards(
		'listing',
		$template_id,
		$list['items'],
		array(
			'card_link_whole'          => $config['cardLinkWhole'],
			'host_page_id'             => $config['hostPageId'],
			'require_login_for_detail' => ! empty( $config['requireLogin'] ),
		)
	);
	$config['initialPagination'] = $list['pagination'];
	$config['initialError']      = $list['error'];
	?>
		<div class="agend-directory-catalogue agend-directory-catalogue--templated agend-filters-<?php echo esc_attr( $config['filterPosition'] ); ?><?php echo esc_attr( agend_apps_records_directory_catalogue_scroll_class( $config ) ); ?>" style="<?php echo esc_attr( $style ); ?>" data-agend-directory-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
			<?php if ( ! empty( $config['heading']['show'] ) && ( '' !== $config['heading']['title'] || '' !== $config['heading']['subtitle'] ) ) : ?>
				<div class="agend-dir-heading">
					<?php if ( '' !== $config['heading']['title'] ) : ?>
						<h2 class="agend-dir-heading__title"><?php echo esc_html( $config['heading']['title'] ); ?></h2>
					<?php endif; ?>
					<?php if ( '' !== $config['heading']['subtitle'] ) : ?>
						<p class="agend-dir-heading__subtitle"><?php echo esc_html( $config['heading']['subtitle'] ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="agend-dir-filter-slot"><?php echo agend_apps_records_directory_catalogue_render_filters( (int) $config['filterTemplate'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Template output. ?></div><?php echo isset( $config['resultCount'] ) ? "\n\t\t\t" . '<p class="agend-dir-count" aria-live="polite">' . esc_html( agend_apps_records_directory_catalogue_count_text( $config['resultCount']['text'], $list['pagination'], (int) $config['pagination']['perPage'] ) ) . '</p>' : ''; ?>

			<div class="agend-dir-status" <?php echo ( empty( $cards ) ) ? '' : 'style="display:none"'; ?>>
				<?php echo $list['error'] ? esc_html__( 'Unable to load listings.', 'agend-apps-core' ) : esc_html__( 'No listings found.', 'agend-apps-core' ); ?>
			</div>
			<div class="agend-dir-grid agend-dir-grid--<?php echo esc_attr( $config['layout']['style'] ); ?> agend-dir-grid--templated" style="--agend-dir-cols-desktop:<?php echo (int) $columns; ?>;--agend-dir-cols-tablet:<?php echo (int) $config['layout']['tablet']; ?>;--agend-dir-cols-mobile:<?php echo (int) $config['layout']['mobile']; ?>;">
				<?php
			foreach ( $cards as $card ) {
				echo $card['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Template output; record values escaped by the field widgets.
			}
			?>
			</div>
			<div class="agend-dir-pager-slot"></div>
		</div>
		<?php
}
