<?php
/**
 * Catalogue list query builders shared by the server-rendered first page and
 * the REST fragment endpoint.
 *
 * Both paths must ask the gateway the same question, or page one (rendered
 * by the widget) and page two (rendered over REST) disagree. The key names
 * here are the ones assets/js/events-catalogue.js and courses-catalogue.js
 * already send to the Agend Apps Core proxy, and the allow-lists mirror the
 * proxy controllers in agend-apps-core/includes/rest/.
 *
 * @package Agend_Apps_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Upper bound on a page size requested over REST.
 */
const AGEND_APPS_RECORDS_FRAGMENT_MAX_LIMIT = 100;

/**
 * Query parameters the fragment endpoint forwards to the gateway for a type.
 *
 * Copied from Agend_Apps_Events_REST_Controller::get_events() and
 * Agend_Apps_LMS_REST_Controller::get_courses() in agend-apps-core.
 *
 * @param string $type 'event' or 'course'.
 * @return string[]
 */
function agend_apps_records_fragment_allowed_params( string $type ): array {
	if ( 'listing' === $type ) {
		return array( 'q', 'search', 'page', 'limit', 'per_page', 'category', 'tag_ids', 'badge_ids', 'custom_fields', 'sponsor_level', 'lat', 'lng', 'radius', 'bbox', 'rating', 'featured', 'sortBy', 'sortOrder', 'excludeCategories', 'city', 'state', 'postcode', 'country', 'locationName' );
	}
	if ( 'course' === $type ) {
		return array( 'page', 'per_page', 'limit', 'search', 'category', 'difficulty', 'deliveryMode', 'excludeCategories', 'excludeDifficulties', 'excludeDeliveryModes', 'sortBy', 'sortOrder' );
	}
	return array( 'page', 'limit', 'search', 'category', 'type', 'city', 'categories', 'types', 'cities', 'categoriesMatch', 'timeframe', 'startAfter', 'startBefore', 'sortBy', 'sortOrder', 'excludeCategories', 'excludeTags', 'excludeVenueTypes', 'excludeCities', 'excludeCategoriesMatch' );
}

/**
 * Reduces raw request parameters to the gateway query for a type.
 *
 * Drops everything not on the allow-list (our own `template`, `detail_page`
 * and friends, the REST nonce, anything injected), keeps array values as
 * arrays (the wrappers split arrays into repeatable gateway params), drops
 * empty scalars, and clamps `limit`.
 *
 * @param array  $params Raw request parameters.
 * @param string $type   'event' or 'course'.
 * @return array
 */
function agend_apps_records_fragment_query_args( array $params, string $type ): array {
	$allowed = agend_apps_records_fragment_allowed_params( $type );
	$query   = array();

	foreach ( $params as $key => $value ) {
		if ( ! in_array( (string) $key, $allowed, true ) ) {
			continue;
		}
		if ( 'custom_fields' === $key ) {
			// A map of field key => matching values or bounds, not a list, so
			// it passes through as-is for add_query_arg() to encode as
			// custom_fields[key] and custom_fields[key][min].
			$map = agend_apps_records_custom_field_filters( $value );
			if ( ! empty( $map ) ) {
				$query[ $key ] = $map;
			}
			continue;
		}
		if ( is_array( $value ) ) {
			$values = array_values( array_filter( array_map( 'strval', array_filter( $value, 'is_scalar' ) ), 'strlen' ) );
			if ( ! empty( $values ) ) {
				$query[ $key ] = $values;
			}
			continue;
		}
		if ( null === $value || '' === $value ) {
			continue;
		}
		$query[ $key ] = is_scalar( $value ) ? $value : (string) $value;
	}

	foreach ( array( 'limit', 'per_page' ) as $size_key ) {
		if ( isset( $query[ $size_key ] ) ) {
			$query[ $size_key ] = max( 1, min( AGEND_APPS_RECORDS_FRAGMENT_MAX_LIMIT, (int) $query[ $size_key ] ) );
		}
	}
	if ( isset( $query['page'] ) ) {
		$query['page'] = max( 1, (int) $query['page'] );
	}

	return $query;
}

/**
 * The events list query for a widget config, matching reloadCatalogue() in
 * assets/js/events-catalogue.js key for key.
 *
 * @param array $config The widget's build_config() output.
 * @param int   $page   Page number.
 * @param array $state  Visitor filter state (search, category, type, city,
 *                      categories, types, cities, startAfter, startBefore).
 * @return array
 */
function agend_apps_records_events_list_args( array $config, int $page = 1, array $state = array() ): array {
	$exclusions = isset( $config['exclusions'] ) && is_array( $config['exclusions'] ) ? $config['exclusions'] : array();
	$filters    = isset( $config['filters'] ) && is_array( $config['filters'] ) ? $config['filters'] : array();

	$args = array(
		'page'                   => max( 1, $page ),
		'limit'                  => (int) ( $config['pagination']['perPage'] ?? 9 ),
		'search'                 => (string) ( $state['search'] ?? '' ),
		'category'               => (string) ( $state['category'] ?? '' ),
		'type'                   => (string) ( $state['type'] ?? '' ),
		'city'                   => (string) ( $state['city'] ?? '' ),
		'categories'             => (array) ( $state['categories'] ?? array() ),
		'types'                  => (array) ( $state['types'] ?? array() ),
		'cities'                 => (array) ( $state['cities'] ?? array() ),
		'categoriesMatch'        => (string) ( $filters['categoryMatch'] ?? 'any' ),
		'timeframe'              => (string) ( $config['timeframe'] ?? 'upcoming' ),
		'startAfter'             => (string) ( $state['startAfter'] ?? '' ),
		'startBefore'            => (string) ( $state['startBefore'] ?? '' ),
		'excludeCategories'      => (array) ( $exclusions['categories'] ?? array() ),
		'excludeVenueTypes'      => (array) ( $exclusions['venueTypes'] ?? array() ),
		'excludeCities'          => (array) ( $exclusions['cities'] ?? array() ),
		'excludeCategoriesMatch' => (string) ( $exclusions['categoryMatch'] ?? 'any' ),
	);

	return agend_apps_records_fragment_query_args( $args, 'event' );
}

/**
 * The courses list query for a widget config, matching reloadCatalogue() in
 * assets/js/courses-catalogue.js key for key.
 *
 * @param array $config The widget's build_config() output.
 * @param int   $page   Page number.
 * @param array $state  Visitor filter state (search, category, difficulty,
 *                      deliveryMode).
 * @return array
 */
function agend_apps_records_courses_list_args( array $config, int $page = 1, array $state = array() ): array {
	$exclusions = isset( $config['exclusions'] ) && is_array( $config['exclusions'] ) ? $config['exclusions'] : array();

	$args = array(
		'page'                 => max( 1, $page ),
		'limit'                => (int) ( $config['pagination']['perPage'] ?? 9 ),
		'search'               => (string) ( $state['search'] ?? '' ),
		'category'             => (string) ( $state['category'] ?? '' ),
		'difficulty'           => (string) ( $state['difficulty'] ?? '' ),
		'deliveryMode'         => (string) ( $state['deliveryMode'] ?? '' ),
		'excludeCategories'    => (array) ( $exclusions['categories'] ?? array() ),
		'excludeDifficulties'  => (array) ( $exclusions['difficulties'] ?? array() ),
		'excludeDeliveryModes' => (array) ( $exclusions['deliveryModes'] ?? array() ),
	);

	return agend_apps_records_fragment_query_args( $args, 'course' );
}

/**
 * The listings query for a widget config, matching reloadCatalogue() in
 * assets/js/directory-catalogue.js key for key.
 *
 * The directory takes comma-joined strings where the other catalogues take
 * repeatable arrays, so the exclusion list is joined here rather than passed
 * through as an array.
 *
 * @param array $config The widget's build_config() output.
 * @param int   $page   Page number.
 * @param array $state  Visitor filter state (search, category, categories, rating,
 *                      location_city, location_state, location_postcode, location_country,
 *                      location_name).
 * @return array
 */
function agend_apps_records_listings_list_args( array $config, int $page = 1, array $state = array() ): array {
	$exclusions = isset( $config['exclusions'] ) && is_array( $config['exclusions'] ) ? $config['exclusions'] : array();
	$categories = (array) ( $state['categories'] ?? array() );

	$args = array(
		'page'              => max( 1, $page ),
		'limit'             => (int) ( $config['pagination']['perPage'] ?? 12 ),
		'search'            => (string) ( $state['search'] ?? '' ),
		'category'          => ! empty( $categories ) ? implode( ',', $categories ) : (string) ( $state['category'] ?? '' ),
		'rating'            => (string) ( $state['rating'] ?? '' ),
		// The widget-level "featured only" setting is a floor; a visitor filter
		// can turn it on but never off.
		'featured'          => ( ! empty( $exclusions['featured'] ) || ! empty( $state['featured'] ) ) ? 'true' : '',
		'tag_ids'           => implode( ',', (array) ( $state['tag_ids'] ?? array() ) ),
		'badge_ids'         => implode( ',', (array) ( $state['badge_ids'] ?? array() ) ),
		'city'              => implode( ',', (array) ( $state['location_city'] ?? array() ) ),
		'state'             => implode( ',', (array) ( $state['location_state'] ?? array() ) ),
		'postcode'          => implode( ',', (array) ( $state['location_postcode'] ?? array() ) ),
		'country'           => implode( ',', (array) ( $state['location_country'] ?? array() ) ),
		// One free-text value, never joined or split. Dropped when blank by
		// agend_apps_records_fragment_query_args() below.
		'locationName'      => agend_apps_records_listings_location_name( $state ),
		'custom_fields'     => agend_apps_records_custom_field_filters( $state['custom_fields'] ?? array() ),
		'excludeCategories' => implode( ',', (array) ( $exclusions['categories'] ?? array() ) ),
		'sortBy'            => agend_apps_records_listings_sort_by( $state ),
		'sortOrder'         => in_array( agend_apps_records_listings_sort_by( $state ), array( 'name', 'distance' ), true ) ? 'asc' : 'desc',
	);

	// A Location filter's point and radius, or a map viewport. The gateway
	// takes one or the other, and a point wins.
	$near = agend_apps_records_listings_near( $state );
	if ( null !== $near ) {
		$args['lat']    = (string) $near['lat'];
		$args['lng']    = (string) $near['lng'];
		$args['radius'] = (string) $near['radius'];
	} elseif ( is_string( $state['bbox'] ?? null ) && '' !== $state['bbox'] ) {
		$args['bbox'] = (string) $state['bbox'];
	}

	return agend_apps_records_fragment_query_args( $args, 'listing' );
}

/**
 * A listing search query carrying the `include` its card template needs.
 *
 * Derived on the server from the fields the template binds, and never taken
 * from the request: any `include` already on the query is replaced. The
 * transient cache key is built from the whole query, so it covers the include.
 *
 * @param array $query       A listing search query.
 * @param int   $template_id The card template the results render through.
 * @return array
 */
function agend_apps_records_with_search_include( array $query, int $template_id ): array {
	unset( $query['include'] );
	if ( ! class_exists( 'Agend_Apps_Templates' ) || ! function_exists( 'agend_apps_records_search_include_for_keys' ) ) {
		return $query;
	}

	$include = agend_apps_records_search_include_for_keys( Agend_Apps_Templates::field_keys( $template_id ) );
	if ( '' !== $include ) {
		$query['include'] = $include;
	}
	return $query;
}

/**
 * The Organisation filter's text from catalogue state, unslashed and trimmed.
 *
 * One value: the gateway never splits it on commas. Blank when the state holds
 * no usable string, so the caller drops it from the query.
 *
 * The state is expected in WordPress's slashed form, as read from a superglobal,
 * so `wp_unslash()` removes every backslash. Do not feed it REST parameters:
 * WordPress has already unslashed those, and a name containing a real backslash
 * would lose it. This is a deliberate divergence from `queryParams()` in
 * assets/js/directory-catalogue.js, which only trims and keeps a backslash. The
 * two agree on every value a visitor types in practice, and the shared fixture
 * holds only those.
 *
 * `trim()` strips ASCII whitespace only, where the script's `String.trim()` also
 * strips a non-breaking space and U+FEFF. The filter box is unaffected, because
 * filters.js trims before it stores the state.
 *
 * @param array $state Visitor filter state, slashed.
 * @return string
 */
function agend_apps_records_listings_location_name( array $state ): string {
	$name = $state['location_name'] ?? '';
	return is_string( $name ) ? trim( wp_unslash( $name ) ) : '';
}

/**
 * A Location filter's point and radius from catalogue state, or null when
 * none is set or any part of it is not a finite number in range.
 *
 * Mirrors nearParams() in assets/js/directory-catalogue.js.
 *
 * @param array $state Visitor filter state.
 * @return array{lat: float, lng: float, radius: float}|null
 */
function agend_apps_records_listings_near( array $state ): ?array {
	$near = $state['near'] ?? null;
	if ( ! is_array( $near ) ) {
		return null;
	}
	foreach ( array( 'lat', 'lng', 'radius' ) as $key ) {
		if ( ! isset( $near[ $key ] ) || ! is_numeric( $near[ $key ] ) || ! is_finite( (float) $near[ $key ] ) ) {
			return null;
		}
	}
	$lat    = (float) $near['lat'];
	$lng    = (float) $near['lng'];
	$radius = (float) $near['radius'];
	if ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 || $radius <= 0 ) {
		return null;
	}
	return array( 'lat' => $lat, 'lng' => $lng, 'radius' => $radius );
}

/**
 * The listings sort for catalogue state, matching effectiveSort() in
 * assets/js/directory-catalogue.js.
 *
 * A location search with no Sort choice orders nearest first, the way a
 * "find near me" search is expected to read. "Nearest" without a location
 * has nothing to measure from, so it falls back to relevance.
 *
 * @param array $state Visitor filter state.
 * @return string
 */
function agend_apps_records_listings_sort_by( array $state ): string {
	$sort     = (string) ( $state['sortBy'] ?? '' );
	$has_near = null !== agend_apps_records_listings_near( $state );
	if ( '' === $sort ) {
		return $has_near ? 'distance' : 'relevance';
	}
	if ( 'distance' === $sort && ! $has_near ) {
		return 'relevance';
	}
	return $sort;
}

/**
 * Fetches a page of records for a catalogue type through the Agend Apps Core
 * wrapper, so the server-rendered first page and the REST fragments call the
 * same thing the browser would.
 *
 * The directory takes its search term as a separate argument and translates
 * `category` to the gateway's canonical `category_ids`, mirroring
 * Agend_Apps_Directory_REST_Controller::search().
 *
 * @param string $type  'event', 'course' or 'listing'.
 * @param array  $query Allow-listed query parameters.
 * @return mixed Wrapper response, WP_Error, or null when unavailable.
 */
function agend_apps_records_fetch_list( string $type, array $query ) {
	if ( 'listing' === $type ) {
		if ( ! function_exists( 'agend_apps_directory_search' ) ) {
			return null;
		}
		$term = (string) ( $query['q'] ?? $query['search'] ?? '' );
		unset( $query['q'], $query['search'] );
		if ( isset( $query['category'] ) ) {
			$query['category_ids'] = $query['category'];
			unset( $query['category'] );
		}
		return agend_apps_directory_search( $term, $query );
	}
	if ( 'course' === $type ) {
		return function_exists( 'agend_apps_lms_get_courses' ) ? agend_apps_lms_get_courses( $query ) : null;
	}
	return function_exists( 'agend_apps_events_get_events' ) ? agend_apps_events_get_events( $query ) : null;
}

/**
 * Normalises custom field filter state into the gateway's wire format.
 *
 * A key holding a list becomes a comma-joined string matching values, and a
 * key holding min/max becomes a bounds map. Empty keys are dropped so an
 * untouched filter contributes nothing to the query.
 *
 * @param mixed $state The `custom_fields` slice of the catalogue state.
 * @return array<string, mixed>
 */
function agend_apps_records_custom_field_filters( $state ): array {
	if ( ! is_array( $state ) ) {
		return array();
	}
	$out = array();
	foreach ( $state as $key => $value ) {
		$key = trim( (string) $key );
		if ( '' === $key ) {
			continue;
		}
		if ( is_array( $value ) && ( isset( $value['min'] ) || isset( $value['max'] ) ) ) {
			$bounds = array();
			foreach ( array( 'min', 'max' ) as $bound ) {
				if ( isset( $value[ $bound ] ) && '' !== $value[ $bound ] ) {
					$bounds[ $bound ] = (string) $value[ $bound ];
				}
			}
			if ( ! empty( $bounds ) ) {
				$out[ $key ] = $bounds;
			}
			continue;
		}
		$values = array_values( array_filter( array_map( 'trim', array_map( 'strval', (array) $value ) ), 'strlen' ) );
		if ( ! empty( $values ) ) {
			$out[ $key ] = implode( ',', $values );
		}
	}
	return $out;
}

/**
 * Normalises a gateway list response into items plus pagination, the shape
 * unwrapList() in the catalogue scripts produces.
 *
 * @param mixed $response Wrapper response (array) or WP_Error.
 * @return array{items: array, pagination: array|null, error: bool}
 */
function agend_apps_records_unwrap_list( $response ): array {
	if ( is_wp_error( $response ) || ! is_array( $response ) ) {
		return array( 'items' => array(), 'pagination' => null, 'error' => true );
	}
	if ( isset( $response['data'] ) && is_array( $response['data'] ) ) {
		$pagination = ( isset( $response['meta']['pagination'] ) && is_array( $response['meta']['pagination'] ) ) ? $response['meta']['pagination'] : null;
		return array( 'items' => array_values( array_filter( $response['data'], 'is_array' ) ), 'pagination' => $pagination, 'error' => false );
	}
	// array_is_list() is PHP 8.1+ and the plugin targets 7.4.
	if ( array() === $response || array_keys( $response ) === range( 0, count( $response ) - 1 ) ) {
		return array( 'items' => array_values( array_filter( $response, 'is_array' ) ), 'pagination' => null, 'error' => false );
	}
	return array( 'items' => array(), 'pagination' => null, 'error' => false );
}
