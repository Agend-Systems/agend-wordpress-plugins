<?php
/**
 * Content-settings schema for the Agend Map (directory map) surface.
 *
 * @package Agend_Apps_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Map height choices, in pixels.
 *
 * @return array<string, string>
 */
function agend_apps_records_directory_map_height_options(): array {
	$options = array();
	foreach ( array( 280, 320, 360, 420, 480, 560, 640, 720, 800 ) as $height ) {
		$options[ (string) $height ] = $height . 'px';
	}
	return $options;
}

/**
 * Preload threshold choices: the most matching listings for which a map
 * loads every pin's details with its pins. Keyed by the values stored as
 * `marker_limit`, so a map saved when it was a pin limit keeps its value.
 *
 * @return array<string, string>
 */
function agend_apps_records_directory_map_preload_options(): array {
	return array(
		'250'  => __( '250 listings', 'agend-apps-core' ),
		'500'  => __( '500 listings', 'agend-apps-core' ),
		'1000' => __( '1,000 listings', 'agend-apps-core' ),
		'2000' => __( '2,000 listings', 'agend-apps-core' ),
	);
}

/**
 * The Agend Map widget's content-settings schema.
 *
 * @return array
 */
function agend_apps_records_schema_directory_map(): array {
	return array(
		'sections' => array(
			array(
				'id'     => 'section_map',
				'label'  => __( 'Map', 'agend-apps-core' ),
				'fields' => array(
					array(
						'name'    => 'map_note',
						'type'    => 'note',
						'content' => __( 'Pins every listing the Directory Catalogue on this page is showing, and follows its filters. With no catalogue on the page it pins every listing that has a map location.', 'agend-apps-core' ),
					),
					array(
						'name'    => 'height',
						'label'   => __( 'Height', 'agend-apps-core' ),
						'type'    => 'select',
						'default' => '480',
						'options' => 'agend_apps_records_directory_map_height_options',
					),
					array(
						'name'    => 'height_mobile',
						'label'   => __( 'Height on phones', 'agend-apps-core' ),
						'type'    => 'select',
						'default' => '360',
						'options' => 'agend_apps_records_directory_map_height_options',
					),
					array(
						'name'        => 'follow_view',
						'label'       => __( 'Show only in Map view', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Hides the map until a visitor picks Map on the catalogue\'s List / Map switch, and hides the results list while it shows. Place the map just below the catalogue. Leave off to show the map beside or below the list all the time.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'cluster',
						'label'       => __( 'Group nearby pins', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => true,
						'description' => __( 'Pins that would overlap are grouped into a numbered circle. A map with more than 2,000 pins always groups them.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'update_on_move',
						'label'       => __( 'Update results as the map moves', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Dragging or zooming the map narrows the catalogue to the area shown. Not applied during a location search, which already sets the area.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'scroll_zoom',
						'label'       => __( 'Zoom with the mouse wheel', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Off by default so scrolling the page never gets caught by the map: visitors zoom by holding Ctrl (or Command on a Mac) as they scroll, and on phones move the map with two fingers. The map shows them how when they try. The zoom buttons always work.', 'agend-apps-core' ),
					),
					array(
						'name'    => 'show_radius',
						'label'   => __( 'Show the search radius', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => true,
					),
					array(
						'name'    => 'fullscreen_button',
						'label'   => __( 'Full screen button', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => true,
					),
					array(
						'name'        => 'locate_button',
						'label'       => __( 'My location button', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => true,
						'description' => __( 'Centres the map on where the visitor is, after their browser asks their permission. It moves the map only; the Location filter is what searches near them.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'marker_limit',
						'label'       => __( 'Preload pin details for up to', 'agend-apps-core' ),
						'type'        => 'select',
						'default'     => '500',
						'options'     => 'agend_apps_records_directory_map_preload_options',
						'description' => __( 'When this many listings match or fewer, every pin\'s details load with the map, so opening a pin is instant. When more match, a pin\'s details load when it is opened. The map always shows every matching listing.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'empty_text',
						'label'       => __( 'No results text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'placeholder' => __( 'No listings with a map location match these filters.', 'agend-apps-core' ),
					),
				),
			),
			array(
				'id'     => 'section_popup',
				'label'  => __( 'Pin details', 'agend-apps-core' ),
				'fields' => array(
					array(
						'name'    => 'popup_logo',
						'label'   => __( 'Show logo', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => true,
					),
					array(
						'name'    => 'popup_category',
						'label'   => __( 'Show category', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => true,
					),
					array(
						'name'        => 'popup_location_name',
						'label'       => __( 'Show location name', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'The name of the location the pin marks, such as the office or branch.', 'agend-apps-core' ),
					),
					array(
						'name'    => 'popup_address',
						'label'   => __( 'Show address', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => true,
					),
					array(
						'name'    => 'popup_distance',
						'label'   => __( 'Show distance', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => true,
					),
					array(
						'name'    => 'popup_rating',
						'label'   => __( 'Show rating', 'agend-apps-core' ),
						'type'    => 'toggle',
						'default' => false,
					),
					array(
						'name'        => 'popup_link_text',
						'label'       => __( 'Link text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'placeholder' => __( 'View details', 'agend-apps-core' ),
					),
					array(
						'name'        => 'popup_directions',
						'label'       => __( 'Show directions link', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => true,
						'description' => __( 'Opens directions to the listing in Google Maps, in a new tab.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'popup_directions_text',
						'label'       => __( 'Directions link text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'placeholder' => __( 'Get directions', 'agend-apps-core' ),
						'condition'   => array( 'popup_directions' => 'yes' ),
					),
				),
			),
			array(
				'id'     => 'section_style_map',
				'label'  => __( 'Map', 'agend-apps-core' ),
				'tab'    => 'style',
				'fields' => array(
					array(
						'name'    => 'style_note',
						'type'    => 'note',
						'content' => __( 'Anything left empty uses the catalogue\'s accent colour, or the map\'s own default.', 'agend-apps-core' ),
					),
					array(
						'name'    => 'pin_colour',
						'label'   => __( 'Pin colour', 'agend-apps-core' ),
						'type'    => 'colour',
						'default' => '',
					),
					array(
						'name'    => 'cluster_colour',
						'label'   => __( 'Group colour', 'agend-apps-core' ),
						'type'    => 'colour',
						'default' => '',
					),
					array(
						'name'    => 'cluster_text_colour',
						'label'   => __( 'Group number colour', 'agend-apps-core' ),
						'type'    => 'colour',
						'default' => '',
					),
					array(
						'name'    => 'radius_colour',
						'label'   => __( 'Search radius colour', 'agend-apps-core' ),
						'type'    => 'colour',
						'default' => '',
					),
					array(
						'name'    => 'link_colour',
						'label'   => __( 'Pin details link colour', 'agend-apps-core' ),
						'type'    => 'colour',
						'default' => '',
					),
					array(
						'name'    => 'border_colour',
						'label'   => __( 'Border colour', 'agend-apps-core' ),
						'type'    => 'colour',
						'default' => '',
					),
					array(
						'name'    => 'border_radius',
						'label'   => __( 'Corner radius', 'agend-apps-core' ),
						'type'    => 'select',
						'default' => '',
						'options' => 'agend_apps_records_filter_radius_options',
					),
				),
			),
		),
	);
}
