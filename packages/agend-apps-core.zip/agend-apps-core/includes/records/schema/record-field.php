<?php
/**
 * Content-settings schema for the Agend Field surface.
 *
 * The Style-tab ("Text") section is untouched and stays hand-declared in the
 * widget.
 *
 * There is deliberately no `record_type` control here. The chosen field names
 * the record type on its own (`listing:name` can only be a listing), so a
 * second control could only ever contradict it: it left the field list
 * offering event fields to a widget an author had already set to Directory
 * listing. `common:` fields follow whatever the surrounding template renders.
 *
 * @package Agend_Apps_Core
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The link-value conditions name the registry's linkable fields.
require_once __DIR__ . '/../fields.php';

/**
 * The Agend Field widget's content-settings schema.
 *
 * @return array
 */
function agend_apps_records_schema_record_field(): array {
	return array(
		'sections' => array(
			array(
				'id'     => 'section_field',
				'label'  => __( 'Field', 'agend-apps-core' ),
				'fields' => array(
					array(
						'name'        => 'field',
						'label'       => __( 'Field', 'agend-apps-core' ),
						'type'        => 'select',
						'default'     => 'common:title',
						'groups'      => 'agend_apps_records_field_options',
						'label_block' => true,
						'description' => __( 'Common fields work in any template, resolving to that record type\'s equivalent. A field from one record type renders only inside a template of that type.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'custom_field_key_choice',
						'label'       => __( 'Custom field', 'agend-apps-core' ),
						'type'        => 'select',
						'default'     => '',
						'options'     => 'agend_apps_records_custom_field_key_options',
						'label_block' => true,
						'description' => __( 'The custom fields this site can read. Which of them a visitor can see depends on their entitlements: one they are not entitled to shows the Restricted text in place of its value.', 'agend-apps-core' ),
						'condition'   => array( 'field' => array( 'common:custom_field', 'common:custom_field_label' ) ),
					),
					array(
						'name'        => 'custom_field_key',
						'label'       => __( 'Custom field key', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'The key as configured in Agend, for example education_level. Use this for a field that does not exist yet, or that this site\'s key cannot enumerate.', 'agend-apps-core' ),
						'condition'   => array(
							'field'                   => array( 'common:custom_field', 'common:custom_field_label' ),
							'custom_field_key_choice' => '',
						),
					),
					array(
						'name'    => 'html_tag',
						'label'   => __( 'HTML tag', 'agend-apps-core' ),
						'type'    => 'select',
						'default' => 'div',
						'options' => array(
							'div'  => 'div',
							'span' => 'span',
							'p'    => 'p',
							'h1'   => 'H1',
							'h2'   => 'H2',
							'h3'   => 'H3',
							'h4'   => 'H4',
							'h5'   => 'H5',
							'h6'   => 'H6',
						),
					),
					array(
						'name'        => 'before_text',
						'label'       => __( 'Text before', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Shown before the value, for example "From " ahead of a price.', 'agend-apps-core' ),
					),
					array(
						'name'    => 'after_text',
						'label'   => __( 'Text after', 'agend-apps-core' ),
						'type'    => 'text',
						'default' => '',
					),
					array(
						'name'        => 'fallback_text',
						'label'       => __( 'Fallback text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Shown when the record has no data for this field. A custom field the visitor is not entitled to shows the Restricted text instead. Leave empty to render nothing.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'restricted_text',
						'label'       => __( 'Restricted text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Shown when the visitor is not entitled to this custom field. Leave empty to use the standard wording, such as "Members only".', 'agend-apps-core' ),
						'condition'   => array( 'field' => 'common:custom_field' ),
					),
					array(
						'name'        => 'item_list_layout',
						'label'       => __( 'Item list layout', 'agend-apps-core' ),
						'type'        => 'select',
						'default'     => 'table',
						'options'     => array(
							'table' => __( 'Table', 'agend-apps-core' ),
							'list'  => __( 'List', 'agend-apps-core' ),
						),
						'description' => __( 'For an item list custom field, such as a centre\'s tenants: a table with a column per item field, or a list with one line per item.', 'agend-apps-core' ),
						'condition'   => array( 'field' => 'common:custom_field' ),
					),
					array(
						'name'        => 'item_list_fields',
						'label'       => __( 'Item fields', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'label_block' => true,
						'description' => __( 'For an item list custom field: the item field keys to show, separated by commas, for example name,area. Leave empty to show them all. They keep the order they are declared in.', 'agend-apps-core' ),
						'condition'   => array( 'field' => 'common:custom_field' ),
					),
					array(
						'name'        => 'link_to_detail',
						'label'       => __( 'Link to detail page', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Ignored when the whole card is already a link.', 'agend-apps-core' ),
					),
					// Off by default: Elementor does not store a setting left at
					// its default, so a default of on would link every existing
					// Agend Field on every site at the next release.
					array(
						'name'        => 'link_value',
						'label'       => __( 'Link the value', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Websites link to the address. Phone numbers become tap-to-call links. Ignored when the whole card is already a link.', 'agend-apps-core' ),
						'condition'   => array(
							'field'           => agend_apps_records_linkable_field_keys(),
							'link_to_detail!' => 'yes',
						),
					),
					array(
						'name'        => 'link_text',
						'label'       => __( 'Link text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Shown instead of the value, for example Visit website or Call us. Leave empty to show the value.', 'agend-apps-core' ),
						'condition'   => array(
							'field'           => agend_apps_records_linkable_field_keys(),
							'link_to_detail!' => 'yes',
							'link_value'      => 'yes',
						),
					),
					array(
						'name'      => 'link_new_tab',
						'label'     => __( 'Open in new tab', 'agend-apps-core' ),
						'type'      => 'toggle',
						'default'   => true,
						'condition' => array(
							'field'           => agend_apps_records_linkable_field_keys( array( 'url' ) ),
							'link_to_detail!' => 'yes',
							'link_value'      => 'yes',
						),
					),
					array(
						'name'      => 'label_heading',
						'label'     => __( 'Label', 'agend-apps-core' ),
						'type'      => 'heading',
						'separator' => 'before',
					),
					array(
						'name'        => 'show_label',
						'label'       => __( 'Show label', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Puts the field\'s own name before the value. A custom field uses the label configured in Agend.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'label_text',
						'label'       => __( 'Label text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Leave empty to use the field\'s own name.', 'agend-apps-core' ),
						'condition'   => array( 'show_label' => 'yes' ),
					),
					array(
						'name'        => 'label_separator',
						'label'       => __( 'After the label', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => ': ',
						'description' => __( 'Printed between the label and the value.', 'agend-apps-core' ),
						'condition'   => array( 'show_label' => 'yes' ),
					),
					array(
						'name'        => 'label_block_display',
						'label'       => __( 'Label on its own line', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'condition'   => array( 'show_label' => 'yes' ),
					),
				),
			),
			array(
				'id'     => 'section_format',
				'label'  => __( 'Formatting', 'agend-apps-core' ),
				'fields' => array(
					array(
						'name'        => 'date_format',
						'label'       => __( 'Date format', 'agend-apps-core' ),
						'type'        => 'select',
						'default'     => '',
						'options'     => array(
							''         => __( 'Site default', 'agend-apps-core' ),
							'j M Y'    => '6 Jul 2026',
							'D, j M Y' => 'Mon, 6 Jul 2026',
							'l, j F Y' => 'Monday, 6 July 2026',
							'j M'      => '6 Jul',
							'j'        => '6',
							'M'        => 'Jul',
							'g:i a'    => '9:00 am',
							'custom'   => __( 'Custom', 'agend-apps-core' ),
						),
						'description' => __( 'Applies to date fields. Date range and date-and-time fields use their fixed format.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'date_format_custom',
						'label'       => __( 'Custom date format', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => 'j M Y',
						'description' => __( 'A PHP date format string.', 'agend-apps-core' ),
						'condition'   => array( 'date_format' => 'custom' ),
					),
					array(
						'name'        => 'price_free_label',
						'label'       => __( 'Free label', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => __( 'Free', 'agend-apps-core' ),
						'description' => __( 'Applies to price fields when the price is zero.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'list_separator',
						'label'       => __( 'List separator', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => ', ',
						'description' => __( 'Applies to list fields such as categories and learning outcomes.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'list_max',
						'label'       => __( 'Maximum list items', 'agend-apps-core' ),
						'type'        => 'number',
						'default'     => 0,
						'min'         => 0,
						'description' => __( '0 shows every item.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'show_rest',
						'label'       => __( 'Show the rest', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'With a maximum set, adds a control after the last item shown that reveals the rest in place, and hides them again.', 'agend-apps-core' ),
					),
					array(
						'name'        => 'overflow_text',
						'label'       => __( 'Overflow text', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => __( '+{n}', 'agend-apps-core' ),
						'description' => __( '{n} is replaced by the number of hidden items.', 'agend-apps-core' ),
						'condition'   => array( 'show_rest' => 'yes' ),
					),
					array(
						'name'      => 'collapse_text',
						'label'     => __( 'Collapse text', 'agend-apps-core' ),
						'type'      => 'text',
						'default'   => __( 'Show less', 'agend-apps-core' ),
						'condition' => array( 'show_rest' => 'yes' ),
					),
					array(
						'name'      => 'rest_style',
						'label'     => __( 'Show the rest as', 'agend-apps-core' ),
						'type'      => 'select',
						'default'   => 'link',
						'options'   => array(
							'link' => __( 'Text link', 'agend-apps-core' ),
							'pill' => __( 'Pill', 'agend-apps-core' ),
						),
						'condition' => array( 'show_rest' => 'yes' ),
					),
					array(
						'name'        => 'bool_true',
						'label'       => __( 'Text when true', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => __( 'Yes', 'agend-apps-core' ),
						'description' => __( 'Applies to yes/no fields such as Sold out.', 'agend-apps-core' ),
						'condition'   => array( 'field!' => 'common:custom_field' ),
					),
					array(
						'name'        => 'bool_false',
						'label'       => __( 'Text when false', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Leave empty to render nothing when false.', 'agend-apps-core' ),
						'condition'   => array( 'field!' => 'common:custom_field' ),
					),
					array(
						'name'        => 'custom_field_bool',
						'label'       => __( 'Show as true or false', 'agend-apps-core' ),
						'type'        => 'toggle',
						'default'     => false,
						'description' => __( 'Yes/no custom fields are detected automatically. Turn this on for a custom field stored as text, such as 1 and 0 or yes and no. A value that does not read as true or false shows as written.', 'agend-apps-core' ),
						'condition'   => array( 'field' => 'common:custom_field' ),
					),
					array(
						'name'        => 'custom_field_bool_true',
						'label'       => __( 'Text when true', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => __( 'True', 'agend-apps-core' ),
						'description' => __( 'Applies to a yes/no custom field.', 'agend-apps-core' ),
						'condition'   => array( 'field' => 'common:custom_field' ),
					),
					array(
						'name'        => 'custom_field_bool_false',
						'label'       => __( 'Text when false', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => __( 'False', 'agend-apps-core' ),
						'description' => __( 'Leave empty to show the Fallback text instead.', 'agend-apps-core' ),
						'condition'   => array( 'field' => 'common:custom_field' ),
					),
					array(
						'name'        => 'number_suffix',
						'label'       => __( 'Number suffix', 'agend-apps-core' ),
						'type'        => 'text',
						'default'     => '',
						'description' => __( 'Applies to number fields, for example " lessons" or "%".', 'agend-apps-core' ),
					),
					array(
						'name'        => 'truncate_chars',
						'label'       => __( 'Truncate to characters', 'agend-apps-core' ),
						'type'        => 'number',
						'default'     => 0,
						'min'         => 0,
						'description' => __( 'Applies to text and HTML fields. HTML fields are reduced to plain text when truncated. 0 keeps the full value.', 'agend-apps-core' ),
					),
				),
			),
		),
	);
}

/**
 * The custom field keys this site can offer an author, as key => label.
 *
 * The gateway has no endpoint enumerating custom field DEFINITIONS: it
 * returns them per record, as `{key,label,type,value}` on the record's
 * `custom_fields`. So the list is read off a real listing, which is
 * entitlement-scoped exactly like everything else the editor sees, and the
 * schema pairs it with a free-text control for a field that this site's key
 * cannot enumerate or that does not exist yet.
 *
 * Sourced from the editor preview record, so opening a panel costs no gateway
 * call the editor was not already making. Only an editor gets the list: the
 * preview fetch is two gateway calls on a cache miss, made with whichever
 * member's bearer is present and cached site-wide, and a front-end render of
 * the widget registers this control too. Its stored value is rendered without
 * consulting the choices.
 *
 * @return array<string, string> '' => the "not listed" placeholder, then
 *                                key => label.
 */
function agend_apps_records_custom_field_key_options(): array {
	$options = array( '' => __( 'Not listed (enter a key below)', 'agend-apps-core' ) );

	if ( ! function_exists( 'agend_apps_records_preview_record' ) || ! agend_apps_records_is_editor_request() ) {
		return $options;
	}

	$record = agend_apps_records_preview_record( 'listing' );
	$fields = isset( $record['custom_fields'] ) && is_array( $record['custom_fields'] ) ? $record['custom_fields'] : array();

	foreach ( $fields as $field ) {
		if ( ! is_array( $field ) || empty( $field['key'] ) ) {
			continue;
		}
		$key             = (string) $field['key'];
		$options[ $key ] = ! empty( $field['label'] ) ? (string) $field['label'] : $key;
	}

	return $options;
}
