/**
 * Agend Export Report widget.
 *
 * A button that downloads one report, or a menu whose trigger opens a list of
 * reports where choosing one downloads it. Parameters are resolved at the
 * moment of the click, so a row reading from the Directory Catalogue picks up
 * whatever the visitor has filtered it down to by then.
 *
 * The download goes through the Agend Apps Core proxy: the API key and the
 * member's bearer stay on the server, and the gateway decides whether this
 * caller may reach the report at all.
 */
(function () {
  'use strict';

  function restBase(cfg) {
    var base = cfg.restBase || (window.agendApps && window.agendApps.restUrl) || '/wp-json/agend-apps/v1';
    return String(base).replace(/\/$/, '');
  }

  function nonce() {
    return (window.agendApps && window.agendApps.nonce) || '';
  }

  // Report names are fetched once per page so a dropdown shows current names
  // rather than whatever they were called when the template was saved.
  var reportIndex = null;

  function loadReportIndex(cfg) {
    if (!reportIndex) {
      reportIndex = fetch(restBase(cfg) + '/directory/export-reports', {
        headers: nonce() ? { 'X-WP-Nonce': nonce() } : {},
        credentials: 'same-origin',
      })
        .then(function (res) { return res.json(); })
        .then(function (body) {
          var list = (body && Array.isArray(body.data)) ? body.data : [];
          var byId = {};
          list.forEach(function (r) { byId[r.id] = r; });
          return byId;
        })
        .catch(function () { return {}; });
    }
    return reportIndex;
  }

  // The cached index above is fine for a label fill-in on page load, but not
  // for deciding what parameters to send: an author who edits a report after
  // the transient was warmed would have that edit silently ignored for up to
  // the transient's TTL. A click asks the gateway directly instead, and only
  // falls back to the cached index when that live call itself fails.
  function loadFreshReportIndex(cfg) {
    return fetch(restBase(cfg) + '/directory/export-reports?fresh=1', {
      headers: nonce() ? { 'X-WP-Nonce': nonce() } : {},
      credentials: 'same-origin',
    })
      .then(function (res) {
        if (!res.ok) {
          throw new Error('fresh export report listing failed: ' + res.status);
        }
        return res.json();
      })
      .then(function (body) {
        var list = (body && Array.isArray(body.data)) ? body.data : [];
        var byId = {};
        list.forEach(function (r) { byId[r.id] = r; });
        return byId;
      })
      .catch(function () { return loadReportIndex(cfg); });
  }

  // The catalogue script publishes its live filter state; a parameter row
  // reading from the catalogue takes its value from there at click time.
  function catalogueState() {
    var registry = window.agendCatalogues || {};
    return (registry.listing && registry.listing.state) || null;
  }

  function stateValue(row, cfg) {
    var state = catalogueState();
    if (!state) {
      return '';
    }
    // Emitted from the filter registry by the server. This used to be a second
    // copy of that mapping, which meant a filter added to the registry read as
    // empty here until somebody remembered this file.
    var keysByFilter = cfg.filterStateKeys || {};

    if (row.filter === 'custom_field') {
      var map = state.custom_fields || {};
      var picked = map[row.customKey];
      return Array.isArray(picked) ? picked.join(',') : String(picked === undefined || picked === null ? '' : picked);
    }

    var key = keysByFilter[row.filter];
    if (!key) {
      return '';
    }
    var value = state[key];
    if (Array.isArray(value)) {
      return value.join(',');
    }
    // The category filter writes a list, but falls back to a single value.
    if (key === 'categories' && (!value || !value.length)) {
      value = state.category;
    }
    return String(value === undefined || value === null ? '' : value);
  }

  // A report names its parameters by an internal condition id and declares the
  // field each one filters on. The mapping rows are written against the field,
  // so this pairs them up per report at click time.
  function parametersFor(report, cfg) {
    var out = {};
    if (!report || !Array.isArray(report.parameters)) {
      return out;
    }
    var declared = report.parameters.map(function (param) { return param.field; });

    report.parameters.forEach(function (param) {
      var row = cfg.parameters.filter(function (r) { return r.field === param.field; })[0];
      if (!row) {
        return;
      }
      var value = row.source === 'catalogue' ? stateValue(row, cfg) : row.value;
      if (value !== '' && value !== undefined && value !== null) {
        out[param.name] = value;
      }
    });

    // A configured row that matches no parameter on this report contributes
    // nothing, and the resulting file is indistinguishable from one where no
    // row was configured at all. Saying so here is what makes a mistyped key
    // discoverable instead of invisible.
    var unmatched = (cfg.parameters || [])
      .map(function (row) { return row.field; })
      .filter(function (field) { return declared.indexOf(field) === -1; });

    if (unmatched.length && window.console && window.console.warn) {
      window.console.warn(
        'Agend export report: no parameter named ' + unmatched.join(', ') +
        ' on report "' + (report.name || report.id) + '". That filter was not applied. This report accepts: ' +
        (declared.length ? declared.join(', ') : 'no parameters') + '.'
      );
    }

    return out;
  }

  // A refusal reads differently depending on what failed. The gateway names
  // the reason; everything here is about who can act on it and how.
  function showRefusal(note, cfg, failure) {
    var code = (failure && failure.agendCode) || '';
    var message = (failure && failure.agendMessage) || '';

    while (note.firstChild) {
      note.removeChild(note.firstChild);
    }

    // No reason given, including any gateway that predates them: say what is
    // likely without implying the site is broken.
    if (!message) {
      note.appendChild(document.createTextNode(cfg.labels.failed));
      return;
    }

    // Nobody but an administrator can turn the feature on, so nobody else is
    // told about it.
    if (code === 'feature_unavailable') {
      note.appendChild(document.createTextNode(cfg.canManage ? cfg.labels.featureUnavailable : cfg.labels.failed));
      return;
    }

    note.appendChild(document.createTextNode(message));

    // The one refusal a visitor can resolve on the spot.
    if (code === 'sign_in_required' && cfg.loginUrl) {
      note.appendChild(document.createTextNode(' '));
      var link = document.createElement('a');
      link.className = 'agend-export__signin-link';
      link.href = cfg.loginUrl;
      link.textContent = cfg.labels.signIn;
      note.appendChild(link);
    }
  }

  function download(root, cfg, reportId, button) {
    if (!reportId) {
      return;
    }
    var format = cfg.format === 'xlsx' ? 'xlsx' : 'csv';

    var original = button.textContent;
    button.disabled = true;
    button.textContent = cfg.labels.working;
    var note = root.querySelector('.agend-export__error');
    if (note) {
      note.textContent = '';
    }

    // With no parameter rows there is nothing to map, so the live listing
    // call would only cost a round trip.
    var hasRows = !!(cfg.parameters && cfg.parameters.length);

    (hasRows ? loadFreshReportIndex(cfg) : loadReportIndex(cfg))
      .then(function (byId) {
        var report = byId[reportId];

        // Absent from whichever index we ended up using (the fresh call and
        // its cached fallback both failed to include it), so parametersFor()
        // below will silently send nothing. Configured parameter rows exist
        // to be applied, so say so rather than leave the widget looking like
        // it filtered when it did not.
        if (!report && hasRows && window.console && window.console.warn) {
          window.console.warn(
            'Agend export report: report "' + reportId + '" was not in the export report listing. ' +
            'Configured parameters could not be applied; the download proceeded unfiltered.'
          );
        }

        var url = restBase(cfg) + '/directory/export-reports/' + encodeURIComponent(reportId) + '?format=' + encodeURIComponent(format);
        var params = parametersFor(report, cfg);
        Object.keys(params).forEach(function (name) {
          url += '&' + encodeURIComponent(name) + '=' + encodeURIComponent(params[name]);
        });
        return fetch(url, {
          headers: nonce() ? { 'X-WP-Nonce': nonce() } : {},
          credentials: 'same-origin',
        });
      })
      .then(function (res) {
        if (!res.ok) {
          // A refusal is not a fault. When the proxy forwards the gateway's
          // canonical envelope, its message is the only one that knows why,
          // so it wins over the generic line.
          return res
            .json()
            .catch(function () { return null; })
            .then(function (body) {
              var envelope = (body && body.error) || {};
              var failure = new Error('export failed: ' + res.status);
              failure.agendCode = typeof envelope.code === 'string' ? envelope.code : '';
              failure.agendMessage = typeof envelope.message === 'string' ? envelope.message : '';
              throw failure;
            });
        }
        var disposition = res.headers.get('Content-Disposition') || '';
        var match = /filename="?([^";]+)"?/i.exec(disposition);
        var name = match ? match[1] : 'export.' + format;
        return res.blob().then(function (blob) { return { blob: blob, name: name }; });
      })
      .then(function (file) {
        // Handed over as a blob rather than navigated to: a plain link would
        // drop the REST nonce, and an error would replace the page with JSON.
        var href = window.URL.createObjectURL(file.blob);
        var link = document.createElement('a');
        link.href = href;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(href);
      })
      .catch(function (e) {
        if (!note) {
          note = document.createElement('p');
          note.className = 'agend-export__error';
          root.appendChild(note);
        }
        showRefusal(note, cfg, e);
      })
      .then(function () {
        button.disabled = false;
        button.textContent = original;
      });
  }

  // Dismissal is bound once for the whole document, on the CAPTURE phase and
  // on pointerdown rather than click. A bubble-phase click listener is at the
  // mercy of anything upstream calling stopPropagation, which the Elementor
  // editor canvas does to intercept widget selection: the menu would then only
  // close by pressing its own trigger again. Capture reaches us first
  // regardless.
  var dismissBound = false;

  function bindDismissal() {
    if (dismissBound) {
      return;
    }
    dismissBound = true;

    document.addEventListener('pointerdown', function (e) {
      Array.prototype.forEach.call(document.querySelectorAll('.agend-export-report.is-open'), function (open) {
        if (!open.contains(e.target)) {
          closeMenu(open);
        }
      });
    }, true);

    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') {
        return;
      }
      Array.prototype.forEach.call(document.querySelectorAll('.agend-export-report.is-open'), function (open) {
        closeMenu(open);
        var trigger = open.querySelector('[data-agend-export-trigger]');
        if (trigger) {
          trigger.focus();
        }
      });
    }, true);
  }

  function closeMenu(root) {
    var trigger = root.querySelector('[data-agend-export-trigger]');
    var menu = root.querySelector('[data-agend-export-menu]');
    if (!trigger || !menu) {
      return;
    }
    menu.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
    root.classList.remove('is-open');
  }

  function openMenu(root) {
    var trigger = root.querySelector('[data-agend-export-trigger]');
    var menu = root.querySelector('[data-agend-export-menu]');
    if (!trigger || !menu) {
      return;
    }
    // Only one menu open at a time, wherever it sits on the page.
    Array.prototype.forEach.call(document.querySelectorAll('.agend-export-report.is-open'), function (other) {
      if (other !== root) {
        closeMenu(other);
      }
    });
    menu.hidden = false;
    trigger.setAttribute('aria-expanded', 'true');
    root.classList.add('is-open');
  }

  function initWidget(root) {
    var cfg;
    try {
      cfg = JSON.parse(root.getAttribute('data-agend-export-config'));
    } catch (e) {
      return;
    }
    if (!cfg || !cfg.reports || !cfg.reports.length || root.getAttribute('data-agend-export-ready') === '1') {
      return;
    }
    root.setAttribute('data-agend-export-ready', '1');

    // Fill in any entry the designer left unlabelled with the report's current
    // name, so a rename in Agend reaches a saved template.
    var unlabelled = root.querySelectorAll('[data-agend-export-submit][data-report-id]');
    if (cfg.mode === 'dropdown') {
      loadReportIndex(cfg).then(function (byId) {
        Array.prototype.forEach.call(unlabelled, function (item) {
          var id = item.getAttribute('data-report-id');
          var configured = cfg.reports.filter(function (r) { return r.id === id; })[0];
          if (configured && configured.label) {
            return;
          }
          var report = byId[id];
          if (report && report.name) {
            item.textContent = report.name;
          }
        });
      });
    }

    Array.prototype.forEach.call(unlabelled, function (item) {
      item.addEventListener('click', function () {
        if (cfg.mode === 'dropdown') {
          closeMenu(root);
        }
        download(root, cfg, item.getAttribute('data-report-id'), item);
      });
    });

    var trigger = root.querySelector('[data-agend-export-trigger]');
    if (trigger) {
      trigger.addEventListener('click', function () {
        if (root.classList.contains('is-open')) {
          closeMenu(root);
        } else {
          openMenu(root);
        }
      });
      bindDismissal();
    }
  }

  function initAll() {
    var nodes = document.querySelectorAll('.agend-export-report[data-agend-export-config]');
    Array.prototype.forEach.call(nodes, initWidget);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  // The editor re-renders a widget on every settings change, replacing its
  // DOM, so the fresh copy needs wiring up again.
  if (window.jQuery) {
    window.jQuery(window).on('elementor/frontend/init', function () {
      if (window.elementorFrontend && window.elementorFrontend.hooks) {
        window.elementorFrontend.hooks.addAction('frontend/element_ready/agend-export-reports.default', function ($scope) {
          var node = $scope && $scope[0] ? $scope[0].querySelector('.agend-export-report[data-agend-export-config]') : null;
          if (node) {
            initWidget(node);
          }
        });
      }
    });
  }
})();
