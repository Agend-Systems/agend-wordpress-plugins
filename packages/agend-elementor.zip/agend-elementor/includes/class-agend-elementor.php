<?php
/**
 * Elementor widget loader for Agend Elementor Widgets.
 *
 * @package Agend_Elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the shared Agend Apps widget category and the Agend Elementor
 * widgets. Reuses the same `agend-apps` category slug established by
 * agend-apps-shop so all Agend widgets group together in the editor.
 */
class Agend_Elementor {

	/**
	 * Elementor widget category slug (shared across Agend plugins).
	 *
	 * @var string
	 */
	const CATEGORY = 'agend-apps';

	/**
	 * Registers Elementor hooks.
	 */
	public function __construct() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		add_action( 'elementor/preview/enqueue_styles', array( $this, 'enqueue_editor_preview_styles' ) );
	}

	/**
	 * Enqueues the stylesheet that keeps Agend widgets inert in the editor.
	 *
	 * Elementor fires this hook only while building the editor's preview
	 * iframe, so the live front end, Elementor's own post preview and the
	 * block editor never load it. See the stylesheet for why the widgets are
	 * switched off there.
	 */
	public function enqueue_editor_preview_styles(): void {
		wp_enqueue_style(
			'agend-elementor-editor-preview',
			AGEND_ELEMENTOR_URL . 'assets/css/editor-preview.css',
			array(),
			AGEND_ELEMENTOR_VERSION
		);
	}

	/**
	 * Registers the Agend Apps widget category with Elementor.
	 *
	 * Adding a category that already exists is a no-op in Elementor, so this is
	 * safe alongside agend-apps-shop.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
	 */
	public function register_category( $elements_manager ): void {
		$elements_manager->add_category(
			self::CATEGORY,
			array(
				'title' => __( 'Agend Apps', 'agend-elementor' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	/**
	 * Registers the Agend Elementor widgets.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 */
	public function register_widgets( $widgets_manager ): void {
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-events-catalogue.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-courses-catalogue.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-jobs-catalogue.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-directory-catalogue.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-directory-map.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-account-link.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-member-login.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-memberships-catalogue.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-header-auth.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-record-field.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-record-image.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-record-link.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-record-block.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-record-pills.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-filter.php';
		require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-export-reports.php';

		$widgets_manager->register( new Agend_Elementor_Events_Catalogue() );
		$widgets_manager->register( new Agend_Elementor_Courses_Catalogue() );
		// Needs a core that ships the jobs-catalogue surface (1.53.0).
		if ( function_exists( 'agend_apps_records_render_jobs_catalogue' ) ) {
			$widgets_manager->register( new Agend_Elementor_Jobs_Catalogue() );
		}
		$widgets_manager->register( new Agend_Elementor_Directory_Catalogue() );
		$widgets_manager->register( new Agend_Elementor_Directory_Map() );
		$widgets_manager->register( new Agend_Elementor_Account_Link() );
		$widgets_manager->register( new Agend_Elementor_Member_Login() );
		$widgets_manager->register( new Agend_Elementor_Memberships_Catalogue() );
		$widgets_manager->register( new Agend_Elementor_Header_Auth() );
		$widgets_manager->register( new Agend_Elementor_Record_Field() );
		$widgets_manager->register( new Agend_Elementor_Record_Image() );
		$widgets_manager->register( new Agend_Elementor_Record_Link() );
		$widgets_manager->register( new Agend_Elementor_Record_Block() );
		$widgets_manager->register( new Agend_Elementor_Record_Pills() );
		$widgets_manager->register( new Agend_Elementor_Filter() );
		$widgets_manager->register( new Agend_Elementor_Export_Reports() );

		// Needs a core that ships the member-jobs surface (1.66.0).
		if ( function_exists( 'agend_apps_records_render_member_jobs' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-member-jobs.php';
			$widgets_manager->register( new Agend_Elementor_Member_Jobs() );
		}

		// Needs a core that ships the learning-paths surface (1.70.0).
		if ( function_exists( 'agend_apps_records_render_learning_paths' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-learning-paths.php';
			$widgets_manager->register( new Agend_Elementor_Learning_Paths() );
		}

		// Needs a core that ships the credential-check surface (1.75.0).
		if ( function_exists( 'agend_apps_records_render_credential_check' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-credential-check.php';
			$widgets_manager->register( new Agend_Elementor_Credential_Check() );
		}

		// Needs a core that ships the member-summary surface (1.75.0).
		if ( function_exists( 'agend_apps_records_render_member_summary' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-member-summary.php';
			$widgets_manager->register( new Agend_Elementor_Member_Summary() );
		}

		// Each needs a core that ships its Community surface (1.75.0).
		if ( function_exists( 'agend_apps_records_render_community_announcements' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-community-announcements.php';
			$widgets_manager->register( new Agend_Elementor_Community_Announcements() );
		}

		if ( function_exists( 'agend_apps_records_render_community_channels' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-community-channels.php';
			$widgets_manager->register( new Agend_Elementor_Community_Channels() );
		}

		if ( function_exists( 'agend_apps_records_render_community_feed' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-community-feed.php';
			$widgets_manager->register( new Agend_Elementor_Community_Feed() );
		}

		// Each needs a core that ships its Resources surface (1.75.0).
		if ( function_exists( 'agend_apps_records_render_resources_collections' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-resources-collections.php';
			$widgets_manager->register( new Agend_Elementor_Resources_Collections() );
		}

		if ( function_exists( 'agend_apps_records_render_resources_search' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-resources-search.php';
			$widgets_manager->register( new Agend_Elementor_Resources_Search() );
		}

		if ( function_exists( 'agend_apps_records_render_resources_ask' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-resources-ask.php';
			$widgets_manager->register( new Agend_Elementor_Resources_Ask() );
		}

		// The directory widgets that sit beside a catalogue. Each renderer
		// lives in Agend Apps Core, which updates independently, so a widget
		// registers only when the core it runs against has its surface.
		if ( function_exists( 'agend_apps_records_render_directory_search' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-directory-search.php';
			$widgets_manager->register( new Agend_Elementor_Directory_Search() );
		}
		if ( function_exists( 'agend_apps_records_render_filter_shortcuts' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-filter-shortcuts.php';
			$widgets_manager->register( new Agend_Elementor_Filter_Shortcuts() );
		}
		if ( function_exists( 'agend_apps_records_render_directory_count' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-directory-count.php';
			$widgets_manager->register( new Agend_Elementor_Directory_Count() );
		}

		// The renderer lives in Agend Apps Core, which updates independently:
		// an older core has no listing enquiry surface to adapt.
		if ( function_exists( 'agend_apps_records_render_listing_enquiry' ) ) {
			require_once AGEND_ELEMENTOR_DIR . 'includes/widgets/class-agend-elementor-listing-enquiry.php';
			$widgets_manager->register( new Agend_Elementor_Listing_Enquiry() );
		}
	}
}

new Agend_Elementor();
