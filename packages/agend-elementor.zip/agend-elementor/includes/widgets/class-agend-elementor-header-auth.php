<?php
/**
 * Elementor header auth-link widget for Agend Elementor Widgets.
 *
 * @package Agend_Elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A single header call-to-action that adapts to the member's session
 * (SPEC-CORE-20260722-wordpress-member-login US-2.8): a signed-out visitor sees
 * a "Log In" link to the configured login page; a signed-in member sees "My
 * Portal", which hands off to the member portal already authenticated (via the
 * Agend Apps Core portal-handoff proxy), plus a sign-out action revealed in a
 * dropdown on hover or keyboard focus. All labels are editable in Elementor.
 *
 * The signed-in/out decision is made client-side from the shared
 * `window.agendApps.loggedIn` signal, so a single cached header markup adapts
 * per member without a per-page server render.
 */
class Agend_Elementor_Header_Auth extends \Elementor\Widget_Base {

	/**
	 * Returns the widget name (unique identifier).
	 *
	 * @return string Widget name.
	 */
	public function get_name(): string {
		return 'agend-header-auth';
	}

	/**
	 * Returns the widget display title.
	 *
	 * @return string Widget title.
	 */
	public function get_title(): string {
		return __( 'Agend Login / Portal Link', 'agend-elementor' );
	}

	/**
	 * Returns the Elementor icon class for the widget.
	 *
	 * @return string Icon class.
	 */
	public function get_icon(): string {
		return 'eicon-lock-user';
	}

	/**
	 * Returns the Elementor categories this widget belongs to.
	 *
	 * @return array List of category slugs.
	 */
	public function get_categories(): array {
		return array( Agend_Elementor::CATEGORY );
	}

	/**
	 * Returns the frontend script handle this widget depends on.
	 *
	 * @return array Script handles.
	 */
	public function get_script_depends(): array {
		return array( 'agend-apps-records-header-auth' );
	}

	/**
	 * Returns the frontend style handle this widget depends on.
	 *
	 * @return array Style handles.
	 */
	public function get_style_depends(): array {
		return array( 'agend-apps-records-header-auth' );
	}

	/**
	 * Registers all Elementor controls for this widget.
	 */
	protected function register_controls(): void {
		Agend_Elementor_Schema_Controls::register( $this, agend_apps_records_surface_schema( 'header-auth' ) );

		$this->start_controls_section(
			'section_style',
			array(
				'label' => __( 'Button', 'agend-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'     => __( 'Alignment', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array(
						'title' => __( 'Left', 'agend-elementor' ),
						'icon'  => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'agend-elementor' ),
						'icon'  => 'eicon-text-align-center',
					),
					'right'  => array(
						'title' => __( 'Right', 'agend-elementor' ),
						'icon'  => 'eicon-text-align-right',
					),
				),
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .agend-header-auth__link',
			)
		);

		$this->add_responsive_control(
			'padding',
			array(
				'label'      => __( 'Padding', 'agend-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', 'rem', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .agend-header-auth__link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'border',
				'selector' => '{{WRAPPER}} .agend-header-auth__link',
			)
		);

		$this->add_responsive_control(
			'border_radius',
			array(
				'label'      => __( 'Border radius', 'agend-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', 'rem', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .agend-header-auth__link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'box_shadow',
				'selector' => '{{WRAPPER}} .agend-header-auth__link',
			)
		);

		$this->start_controls_tabs( 'colour_tabs' );

		$this->start_controls_tab(
			'tab_normal',
			array( 'label' => __( 'Normal', 'agend-elementor' ) )
		);

		$this->add_control(
			'text_colour',
			array(
				'label'     => __( 'Text colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__link' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bg_colour',
			array(
				'label'     => __( 'Background', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__link' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_hover',
			array( 'label' => __( 'Hover', 'agend-elementor' ) )
		);

		$this->add_control(
			'text_colour_hover',
			array(
				'label'     => __( 'Text colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__link:hover, {{WRAPPER}} .agend-header-auth__link:focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bg_colour_hover',
			array(
				'label'     => __( 'Background', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__link:hover, {{WRAPPER}} .agend-header-auth__link:focus' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_colour_hover',
			array(
				'label'     => __( 'Border colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__link:hover, {{WRAPPER}} .agend-header-auth__link:focus' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_dropdown_style',
			array(
				'label' => __( 'Sign-out dropdown', 'agend-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'menu_bg_colour',
			array(
				'label'     => __( 'Dropdown background', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__menu' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'menu_text_colour',
			array(
				'label'     => __( 'Item text colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__menu-item' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'menu_text_colour_hover',
			array(
				'label'     => __( 'Item text colour (hover)', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__menu-item:hover, {{WRAPPER}} .agend-header-auth__menu-item:focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'menu_bg_colour_hover',
			array(
				'label'     => __( 'Item background (hover)', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .agend-header-auth__menu-item:hover, {{WRAPPER}} .agend-header-auth__menu-item:focus' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Echoes the surface, rendered by Agend Apps Core from this widget's settings.
	 *
	 * The link is rendered client-side by assets/js/header-auth.js from the
	 * config and the shared `window.agendApps.loggedIn` signal, so one cached
	 * header adapts per member. In `wordpress` mode nothing populates that
	 * signal, so the config carries the session state instead
	 * (docs/PLAN-wordpress-idp-option-b.md section 4.5).
	 */
	protected function render(): void {
		$credential_enabled = ! class_exists( 'Agend_Apps_Settings' ) || Agend_Apps_Settings::credential_login_enabled();
		$wordpress_enabled  = class_exists( 'Agend_Apps_Settings' ) && Agend_Apps_Settings::wordpress_idp_enabled();

		// SPEC-CORE-20260907 US-4.1 AC7 / docs/PLAN-wordpress-idp-option-b.md
		// section 4.5: this is a "Log In / My Portal" control, meaningful in
		// every mode where a member actually signs in somewhere -- `wordpress`
		// included. Only `sso` mode has nothing for it to point at, so it
		// alone still stands down.
		if ( ! $credential_enabled && ! $wordpress_enabled ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div class="agend-widget-notice">' . esc_html__( 'Member sign-in is set to SSO in Agend Apps settings.', 'agend-elementor' ) . '</div>';
			}
			return;
		}

		echo agend_apps_records_render_header_auth( $this->get_settings_for_display() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the core renderer.
	}
}
