<?php
/**
 * Elementor "Agend Pills" widget: a record's categories, tags or other terms,
 * one styled pill per term.
 *
 * @package Agend_Elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The pill count follows the record, so an event with three tags renders three
 * pills from one widget. An Agend Field styled to look like a pill cannot do
 * that: it renders one element holding a joined list, so three tags become one
 * wide chip reading "a, b, c".
 *
 * Elementor omits a widget entirely when its render produces no output, so a
 * record with no terms leaves nothing behind either way.
 */
class Agend_Elementor_Record_Pills extends \Elementor\Widget_Base {

	use Agend_Elementor_Field_Widget_Trait;

	public function get_name(): string {
		return 'agend-record-pills';
	}

	public function get_title(): string {
		return __( 'Agend Pills', 'agend-elementor' );
	}

	public function get_icon(): string {
		return 'eicon-tags';
	}

	public function get_categories(): array {
		return array( Agend_Elementor::CATEGORY );
	}

	public function get_keywords(): array {
		return array( 'agend', 'pill', 'tag', 'category', 'badge', 'chip', 'taxonomy' );
	}

	public function get_style_depends(): array {
		return array( 'agend-apps-records-record-fields' );
	}

	protected function register_controls(): void {
		Agend_Elementor_Schema_Controls::register( $this, agend_apps_records_surface_schema( 'record-pills' ) );

		$this->start_controls_section(
			'section_pill_style',
			array(
				'label' => __( 'Pills', 'agend-elementor' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'align',
			array(
				'label'     => __( 'Alignment', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => __( 'Left', 'agend-elementor' ), 'icon' => 'eicon-text-align-left' ),
					'center'     => array( 'title' => __( 'Centre', 'agend-elementor' ), 'icon' => 'eicon-text-align-center' ),
					'flex-end'   => array( 'title' => __( 'Right', 'agend-elementor' ), 'icon' => 'eicon-text-align-right' ),
				),
				'default'   => 'flex-start',
				'selectors' => array( '{{WRAPPER}} .agend-pills' => 'justify-content: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'gap',
			array(
				'label'      => __( 'Gap between pills', 'agend-elementor' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'default'    => array( 'size' => 6, 'unit' => 'px' ),
				'selectors'  => array( '{{WRAPPER}} .agend-pills' => 'gap: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_control(
			'pill_colour',
			array(
				'label'     => __( 'Text colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#FF6B55',
				'selectors' => array( '{{WRAPPER}} .agend-pill' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'pill_background',
			array(
				'label'     => __( 'Background colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => 'rgba(255, 107, 85, 0.12)',
				'selectors' => array( '{{WRAPPER}} .agend-pill' => 'background-color: {{VALUE}};' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'selector' => '{{WRAPPER}} .agend-pill',
			)
		);

		$this->add_responsive_control(
			'pill_padding',
			array(
				'label'      => __( 'Padding', 'agend-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'default'    => array( 'top' => '3', 'right' => '8', 'bottom' => '3', 'left' => '8', 'unit' => 'px', 'isLinked' => false ),
				'selectors'  => array( '{{WRAPPER}} .agend-pill' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'pill_radius',
			array(
				'label'      => __( 'Border radius', 'agend-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'default'    => array( 'top' => '999', 'right' => '999', 'bottom' => '999', 'left' => '999', 'unit' => 'px', 'isLinked' => true ),
				'selectors'  => array( '{{WRAPPER}} .agend-pill' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'pill_border',
				'selector' => '{{WRAPPER}} .agend-pill',
			)
		);

		$this->add_control(
			'label_style_heading',
			array(
				'label'     => __( 'Label', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'show_label' => 'yes' ),
			)
		);

		$this->add_control(
			'label_colour',
			array(
				'label'     => __( 'Label colour', 'agend-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .agend-pills__label' => 'color: {{VALUE}};' ),
				'condition' => array( 'show_label' => 'yes' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'      => 'label_typography',
				'selector'  => '{{WRAPPER}} .agend-pills__label',
				'condition' => array( 'show_label' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Echoes the surface, rendered by Agend Apps Core from this widget's
	 * settings. The "renders nothing, and why" conditions live in
	 * agend_apps_records_record_pills_render_reason(); this widget only maps
	 * the reason it gets back to the translated notice it already owned.
	 */
	protected function render(): void {
		$s = $this->get_settings_for_display();

		$is_editor = $this->is_editor();
		$opts      = array(
			'preview'      => $is_editor,
			'preview_type' => $is_editor ? $this->preview_type() : '',
		);

		switch ( agend_apps_records_record_pills_render_reason( $s, $opts ) ) {
			case 'field_not_applicable':
				$this->render_editor_notice( __( 'These terms do not exist on the record type this template renders.', 'agend-elementor' ) );
				return;

			case 'no_terms':
				$this->render_editor_notice( __( 'This record has no terms for this field, so nothing renders here on the live site.', 'agend-elementor' ) );
				return;
		}

		echo agend_apps_records_render_record_pills( $s, $opts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the core renderer.
	}
}
